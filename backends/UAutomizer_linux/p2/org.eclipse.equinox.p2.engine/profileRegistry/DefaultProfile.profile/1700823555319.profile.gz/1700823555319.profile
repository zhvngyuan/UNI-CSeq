<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1700823555319'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.cache' value='/storage/repos/ultimate-2/trunk/source/BA_SiteRepository/target/products/CLI-E4/linux/gtk/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_GB'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/storage/repos/ultimate-2/trunk/source/BA_SiteRepository/target/products/CLI-E4/linux/gtk/x86_64'/>
    <property name='eclipse.touchpoint.launcherName' value='Ultimate'/>
  </properties>
  <units size='202'>
    <unit id='BA_FeatureDependenciesCommon.feature.group' version='0.2.4' singleton='false'>
      <update id='BA_FeatureDependenciesCommon.feature.group' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='BA_FeatureDependenciesCommon'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='BA_FeatureDependenciesCommon'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureDependenciesCommon.feature.group' version='0.2.4'/>
      </provides>
      <requires size='57'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.gson' range='[2.8.2.v20180104-1110,2.8.2.v20180104-1110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' range='[67.1.0.v20200706-1749,67.1.0.v20200706-1749]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind' range='[2.2.0.v201505121915,2.2.0.v201505121915]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.inject' range='[1.0.0.v20091030,1.0.0.v20091030]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.xml' range='[1.3.4.v201005080400,1.3.4.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.xml.bind' range='[2.2.0.v201105210648,2.2.0.v201105210648]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.xml.stream' range='[1.0.1.v201004272200,1.0.1.v201004272200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.io' range='[2.6.0.v20190123-2029,2.6.0.v20190123-2029]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.2.0.v20180409-1502,1.2.0.v20180409-1502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.1.16.v20200110-1820,2.1.16.v20200110-1820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xerces' range='[2.9.0.v201101211617,2.9.0.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xml.resolver' range='[1.2.0.v201005080400,1.2.0.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xml.serializer' range='[2.7.1.v201005080400,2.7.1.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core' range='[7.0.1.202010091427,7.0.1.202010091427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.native' range='[6.0.0.202009030027,6.0.0.202009030027]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.win32.x86_64' range='[6.0.0.202008310002,6.0.0.202008310002]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.linux.x86_64' range='[6.0.0.202008310002,6.0.0.202008310002]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.linux' range='[6.0.0.202008310002,6.0.0.202008310002]'>
          <filter>
            (osgi.os=linux)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.win32' range='[6.0.0.202008310002,6.0.0.202008310002]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.macosx' range='[6.0.0.202008310002,6.0.0.202008310002]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.9.700.v20191217-1850,3.9.700.v20191217-1850]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.7.800.v20200724-0804,3.7.800.v20200724-0804]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.7.0.v20200720-1126,3.7.0.v20200720-1126]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.6.1000.v20200409-1035,3.6.1000.v20200409-1035]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.7.700.v20200110-1734,1.7.700.v20200110-1734]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86_64' range='[1.4.200.v20190812-0909,1.4.200.v20190812-0909]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' range='[1.2.300.v20180828-0158,1.2.300.v20180828-0158]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx' range='[1.3.200.v20190903-0945,1.3.200.v20190903-0945]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.10.800.v20200421-0950,3.10.800.v20200421-0950]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.13.800.v20200706-2152,3.13.800.v20200706-2152]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86_64' range='[3.5.400.v20190812-0909,3.5.400.v20190812-0909]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.19.0.v20200724-1004,3.19.0.v20200724-1004]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.4.800.v20200120-1101,3.4.800.v20200120-1101]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.5.0.v20200717-0620,1.5.0.v20200717-0620]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.bidi' range='[1.3.0.v20200612-1624,1.3.0.v20200612-1624]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.13.0.v20200828-1034,3.13.0.v20200828-1034]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.8.0.v20200422-1833,3.8.0.v20200422-1833]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.9.0.v20200625-1425,3.9.0.v20200625-1425]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.11.100.v20200720-0748,3.11.100.v20200720-0748]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.9.0.v20200511-1725,3.9.0.v20200511-1725]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.16.0.v20200828-0759,3.16.0.v20200828-0759]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.5.300.v20190708-1141,3.5.300.v20190708-1141]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.10.300.v20200807-0831,3.10.300.v20200807-0831]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.jdom' range='[1.1.1.v201101151400,1.1.1.v201101151400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna' range='[5.6.0.v20200716-0148,5.6.0.v20200716-0148]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform' range='[5.6.0.v20200722-0209,5.6.0.v20200722-0209]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j' range='[1.2.15.v201012070815,1.2.15.v201012070815]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.logging.log4j' range='[2.8.2.v20200818-1118,2.8.2.v20200818-1118]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.managedbuilder.core' range='[9.0.0.202009010132,9.0.0.202009010132]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.make.core' range='[7.5.0.202009040332,7.5.0.202009040332]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.annotation' range='[2.2.600.v20200408-1511,2.2.600.v20200408-1511]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.templates.freemarker' range='[1.2.0.202008311307,1.2.0.202008311307]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.freemarker' range='[2.3.22.v20160210-1233,2.3.22.v20160210-1233]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.build.gcc.core' range='[1.1.0.202008310002,1.1.0.202008310002]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.templates.core' range='[1.2.0.202008310315,1.2.0.202008310315]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.activation' range='[1.1.0.v201211130549,1.1.0.v201211130549]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureDependenciesCommon.feature.jar' range='[0.2.4,0.2.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <filter>
        (osgi.arch=x86_64)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='BA_FeatureDependenciesCommon.feature.jar' version='0.2.4'>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='BA_FeatureDependenciesCommon'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='BA_FeatureDependenciesCommon'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureDependenciesCommon.feature.jar' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='BA_FeatureDependenciesCommon' version='0.2.4'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='BA_FeatureDependenciesCommon' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='BA_FeatureUltimateCommandLine.feature.group' version='0.2.4' singleton='false'>
      <update id='BA_FeatureUltimateCommandLine.feature.group' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='BA_FeatureUltimateCommandLine'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='BA_FeatureUltimateCommandLine'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommandLine.feature.group' version='0.2.4'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureDependenciesCommon.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommon.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.cli' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.cli' range='[1.3.1,1.3.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommandLine.feature.jar' range='[0.2.4,0.2.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <filter>
        (osgi.arch=x86_64)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='BA_FeatureUltimateCommandLine.feature.jar' version='0.2.4'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BA_FeatureUltimateCommandLine'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='BA_FeatureUltimateCommandLine'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommandLine.feature.jar' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='BA_FeatureUltimateCommandLine' version='0.2.4'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='BA_FeatureUltimateCommandLine' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='BA_FeatureUltimateCommon.feature.group' version='0.2.4' singleton='false'>
      <update id='BA_FeatureUltimateCommon.feature.group' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='BA_FeatureUltimateCommon'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value=''/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='BA_FeatureUltimateCommon'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommon.feature.group' version='0.2.4'/>
      </provides>
      <requires size='74'>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureDependenciesCommon.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.printer' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.ltl2aut' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.witnessprinter' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.acsl.parser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.astbuilder' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.parser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.cdt.parser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.github.jhoenicke.javacup' range='[1.2.0,1.2.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.lang' range='[3.12.0,3.12.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.sourceforge.czt' range='[1.5.0,1.5.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.lmax.disruptor' range='[3.3.5,3.3.5]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='net.sf.javabdd' range='[0.6.0,0.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='[0.9.5,0.9.5]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.pea' range='[0.89.0,0.89.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.srparse' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.core' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.util' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.pea2boogie' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='[2.0.0,2.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.core' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.ojalgo' range='[38.18.0,38.18.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='edu.uci.ics.jung' range='[2.0.1,2.0.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.source.smtparser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.req.printer' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.reqparser' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.pdr' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.reqtotest' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.chcprinter' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.mso' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.sifa' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.sifa' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.mcr' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.preferencejson' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommon.feature.jar' range='[0.2.4,0.2.4]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(|(osgi.os=linux)(osgi.os=macosx)(osgi.os=win32)))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='' url=''>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='' url=''>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='BA_FeatureUltimateCommon.feature.jar' version='0.2.4'>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='BA_FeatureUltimateCommon'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value=''/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='BA_FeatureUltimateCommon'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommon.feature.jar' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='BA_FeatureUltimateCommon' version='0.2.4'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='BA_FeatureUltimateCommon' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='' url=''>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='' url=''>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='CLI-E4' version='0.2.4'>
      <update id='CLI-E4' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Ultimate-CommandLine'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='CLI-E4' version='0.2.4'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommon.feature.group' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(|(osgi.os=linux)(osgi.os=macosx)(osgi.os=win32)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureUltimateCommandLine.feature.group' range='[0.2.4,0.2.4]'>
          <filter>
            (osgi.arch=x86_64)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.application' range='[0.2.4,0.2.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='BA_FeatureDependenciesCommon.feature.group' range='[0.2.4,0.2.4]'>
          <filter>
            (osgi.arch=x86_64)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.configuration' range='[0.2.4,0.2.4]'/>
        <required namespace='osgi.ee' name='JavaSE' range='[11.0.0,11.0.0]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[11.0.0,11.0.0]'>
          <filter>
            (osgi.os=linux)
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='[11.0.0,11.0.0]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='CLI-E4.executable.gtk.linux.x86_64' version='0.2.4'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.gtk.linux.x86_64' version='0.2.4'/>
        <provided namespace='toolingCLI-E4' name='CLI-E4.executable' version='0.2.4'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='CLI-E4.executable.gtk.linux.x86_64' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='CLI-E4.executable.gtk.linux.x86_64.Ultimate' version='0.2.4' singleton='false'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.gtk.linux.x86_64.Ultimate' version='0.2.4'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setLauncherName(name:Ultimate)
          </instruction>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='a.jre.javase' version='14.0.0' singleton='false'>
      <provides size='208'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='14.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.activation' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.acl' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='12.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='13.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='14.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='11.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='com.github.jhoenicke.javacup' version='1.2.0' singleton='false' generation='2'>
      <update id='com.github.jhoenicke.javacup' range='[0.0.0,1.2.0)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='JavaCup Plug-in'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='com.github.jhoenicke.javacup'/>
        <property name='maven-version' value='1.2.0'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.github.jhoenicke.javacup' version='1.2.0'/>
        <provided namespace='osgi.bundle' name='com.github.jhoenicke.javacup' version='1.2.0'/>
        <provided namespace='java.package' name='com.github.jhoenicke.javacup.runtime' version='0.0.0'/>
        <provided namespace='osgi.identity' name='com.github.jhoenicke.javacup' version='1.2.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.github.jhoenicke.javacup' version='1.2.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.github.jhoenicke.javacup&#xA;Bundle-Version: 1.2.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.google.gson' version='2.8.2.v20180104-1110' singleton='false'>
      <update id='com.google.gson' range='[0.0.0,2.8.2.v20180104-1110)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Gson: Google Json Library for Java'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Gson JSON library'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.contact' value='https://github.com/google/gson'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='com.google.gson'/>
        <property name='maven-version' value='2.8.2-SNAPSHOT'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.google.gson' version='2.8.2.v20180104-1110'/>
        <provided namespace='osgi.bundle' name='com.google.gson' version='2.8.2.v20180104-1110'/>
        <provided namespace='java.package' name='com.google.gson.internal' version='2.8.2'/>
        <provided namespace='java.package' name='com.google.gson.internal.bind' version='2.8.2'/>
        <provided namespace='java.package' name='com.google.gson.internal.bind.util' version='2.8.2'/>
        <provided namespace='java.package' name='com.google.gson' version='2.8.2'/>
        <provided namespace='java.package' name='com.google.gson.annotations' version='2.8.2'/>
        <provided namespace='java.package' name='com.google.gson.reflect' version='2.8.2'/>
        <provided namespace='java.package' name='com.google.gson.stream' version='2.8.2'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='com.google.gson' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='com.google.gson.annotations' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='com.google.gson.internal' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='com.google.gson.internal.bind' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='com.google.gson.internal.bind.util' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='com.google.gson.reflect' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='com.google.gson.stream' range='[2.8.0,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.google.gson' version='2.8.2.v20180104-1110'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.google.gson&#xA;Bundle-Version: 2.8.2.v20180104-1110
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.ibm.icu' version='67.1.0.v20200706-1749' singleton='false' generation='2'>
      <update id='com.ibm.icu' range='[0.0.0,67.1.0.v20200706-1749)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='ICU4J'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='International Components for Unicode for Java'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='com.ibm.icu'/>
        <property name='maven-version' value='67.1.0-SNAPSHOT'/>
      </properties>
      <provides size='32'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' version='67.1.0.v20200706-1749'/>
        <provided namespace='osgi.bundle' name='com.ibm.icu' version='67.1.0.v20200706-1749'/>
        <provided namespace='java.package' name='com.ibm.icu' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.coll' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.brkitr' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.coll' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.curr' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.lang' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.rbnf' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.region' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.translit' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.unit' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt67b.zone' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.duration' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.duration.impl' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.duration.impl.data' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.locale' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.number' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.number.parse' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.number.range' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.text' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.lang' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.math' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.number' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.text' version='67.1.0'/>
        <provided namespace='java.package' name='com.ibm.icu.util' version='67.1.0'/>
        <provided namespace='osgi.identity' name='com.ibm.icu' version='67.1.0.v20200706-1749'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.ibm.icu' version='67.1.0.v20200706-1749'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.ibm.icu&#xA;Bundle-Version: 67.1.0.v20200706-1749
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.lmax.disruptor' version='3.3.5' singleton='false' generation='2'>
      <update id='com.lmax.disruptor' range='[0.0.0,3.3.5)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='com.lmax.disruptor'/>
        <property name='org.eclipse.equinox.p2.provider' value='https://github.com/LMAX-Exchange/disruptor'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.lmax.disruptor' version='3.3.5'/>
        <provided namespace='osgi.bundle' name='com.lmax.disruptor' version='3.3.5'/>
        <provided namespace='java.package' name='com.lmax.disruptor' version='0.0.0'/>
        <provided namespace='java.package' name='com.lmax.disruptor.collections' version='0.0.0'/>
        <provided namespace='java.package' name='com.lmax.disruptor.dsl' version='0.0.0'/>
        <provided namespace='java.package' name='com.lmax.disruptor.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='com.lmax.disruptor' version='3.3.5'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='com.lmax.disruptor' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.lmax.disruptor.dsl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.lmax.disruptor.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='sun.misc' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            com.lmax.disruptor
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.lmax.disruptor
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.lmax.disruptor' version='3.3.5'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.lmax.disruptor&#xA;Bundle-Version: 3.3.5
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.jna' version='5.6.0.v20200716-0148' singleton='false' generation='2'>
      <update id='com.sun.jna' range='[0.0.0,5.6.0.v20200716-0148)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Java Native Access'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='JNA Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='com.sun.jna'/>
        <property name='maven-version' value='5.6.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna' version='5.6.0.v20200716-0148'/>
        <provided namespace='osgi.bundle' name='com.sun.jna' version='5.6.0.v20200716-0148'/>
        <provided namespace='java.package' name='com.sun.jna' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.internal' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.ptr' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.win32' version='5.6.0'/>
        <provided namespace='osgi.identity' name='com.sun.jna' version='5.6.0.v20200716-0148'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='com.sun.jna' range='[5.6.0,6.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.jna.internal' range='[5.6.0,6.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.jna.win32' range='[5.6.0,6.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.jna' version='5.6.0.v20200716-0148'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.jna&#xA;Bundle-Version: 5.6.0.v20200716-0148
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.jna.platform' version='5.6.0.v20200722-0209' singleton='false' generation='2'>
      <update id='com.sun.jna.platform' range='[0.0.0,5.6.0.v20200722-0209)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Java Native Access Platform'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='JNA Platform Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='com.sun.jna.platform'/>
        <property name='maven-version' value='5.6.0-SNAPSHOT'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform' version='5.6.0.v20200722-0209'/>
        <provided namespace='osgi.bundle' name='com.sun.jna.platform' version='5.6.0.v20200722-0209'/>
        <provided namespace='java.package' name='com.sun.jna.platform' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.dnd' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.linux' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.mac' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.unix' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.unix.solaris' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.win32' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb.imp' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.util' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.util.annotation' version='5.6.0'/>
        <provided namespace='java.package' name='com.sun.jna.platform.wince' version='5.6.0'/>
        <provided namespace='osgi.identity' name='com.sun.jna.platform' version='5.6.0.v20200722-0209'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='java.package' name='com.sun.jna' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.internal' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.mac' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.unix' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.win32' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.win32.COM' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb.imp' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.win32.COM.util' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.win32.COM.util.annotation' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.ptr' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='com.sun.jna.win32' range='[5.6.0,5.7.0)'/>
        <required namespace='java.package' name='javax.swing' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.swing.text' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.4))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.jna.platform' version='5.6.0.v20200722-0209'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.jna.platform&#xA;Bundle-Version: 5.6.0.v20200722-0209
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.xml.bind' version='2.2.0.v201505121915' singleton='false'>
      <update id='com.sun.xml.bind' range='[0.0.0,2.2.0.v201505121915)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='Java Architecture for XML Binding (JAXB) Implementation'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='3843'/>
        <property name='iplog.contact.name' value='Blaise Doughan'/>
        <property name='iplog.contact.email' value='blaise.doughan@oracle.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='34'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind' version='2.2.0.v201505121915'/>
        <provided namespace='osgi.bundle' name='com.sun.xml.bind' version='2.2.0.v201505121915'/>
        <provided namespace='java.package' name='com.sun.istack' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.istack.localization' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.istack.logging' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.annotation' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.api' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.api.impl' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.marshaller' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.unmarshaller' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.util' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.bytecode' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.model.annotation' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.model.core' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.model.impl' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.model.nav' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.model.runtime' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.runtime' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.runtime.output' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.runtime.property' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.runtime.reflect' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.runtime.reflect.opt' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.runtime.unmarshaller' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.schemagen' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.schemagen.episode' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.schemagen.xmlschema' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.bind.v2.util' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.txw2' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.txw2.annotation' version='2.2.0'/>
        <provided namespace='java.package' name='com.sun.xml.txw2.output' version='2.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.sax' range='[1.2.2,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.stax' range='[1.2.2,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jvnet.fastinfoset' range='[1.2.2,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jvnet.staxex' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.activation' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.bind' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.bind.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.bind.annotation.adapters' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.bind.attachment' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.bind.helpers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.datatype' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream' range='[1.0.1,2.0.0)'/>
        <required namespace='java.package' name='javax.xml.stream.events' range='[1.0.1,2.0.0)'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.sax' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.validation' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.xml.bind' version='2.2.0.v201505121915'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.xml.bind&#xA;Bundle-Version: 2.2.0.v201505121915
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.acsl.parser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.acsl.parser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ACSLParser'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.acsl.parser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.acsl.parser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.acsl.parser' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.acsl.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.model.acsl' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.model.acsl.ast' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.acsl.parser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.astbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.acsl.parser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.acsl.parser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.astbuilder' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.astbuilder' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ASTBuilder'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.astbuilder'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.astbuilder' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.astbuilder' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.astbuilder' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.astbuilder' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.astbuilder' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.astbuilder&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.boogie.parser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.boogie.parser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='BoogieParser Plug-in'/>
        <property name='org.eclipse.equinox.p2.provider' value='Ultimate@Uni'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.boogie.parser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.parser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.parser' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.parser' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.boogie.parser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.boogie.parser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.boogie.parser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Boogie Preprocessor'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.boogie.preprocessor'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.symboltable' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.parser' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.boogie.preprocessor;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.boogie.printer' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.boogie.printer' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BoogiePrinter Plug-in'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.boogie.printer'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.printer' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.printer' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.printer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.boogie.printer' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.parser' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.boogie.printer' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.boogie.printer;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BoogieProcedureInliner'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.boogie.procedureinliner' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.boogie.procedureinliner;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BuchiProgramProduct'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.buchiprogramproduct'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.ltl2aut' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.buchiprogramproduct' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.buchiprogramproduct;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.cdt.parser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.cdt.parser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='CDTParser'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.cdt.parser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.cdt.parser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.cdt.parser' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.cdt.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.cdt.decorator' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.cdt.parser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.managedbuilder.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.build.gcc.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.acsl.parser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.cdt.parser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.cdt.parser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.chcprinter' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.chcprinter' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ChcSmtPrinter Plug-in'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.chcprinter'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.chcprinter' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.chcprinter' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.chcprinter' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.chcprinter' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.chcprinter' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.chcprinter;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.cli' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.cli' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='UltimateCLI'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.cli'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.cli' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.cli' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.cli' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.cli.exceptions' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.cli' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.commons.cli' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.preferencejson' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.cli' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.cli;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.core' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.core' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='CoreRCP Plug-in'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.core'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.core' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.external' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.modelrepository' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.modelwalker' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.services' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.coreplugin.toolchain' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.ep' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.core' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.log4j' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.commons.lang' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.astbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.core' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.core;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-AcceleratedInterpolation'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.automata' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.automata' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-Automata'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.automata'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='64'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.automata' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.alternating' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.alternating.visualization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.counting' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.counting.datastructures' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.buchi' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.incrementalinclusion' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.minimization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.minimization.maxsat.arrays' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.minimization.maxsat.collections' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.minimization.parallel' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.minimization.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.oldapi' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.optncsb' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.optncsb.automata' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.optncsb.complement' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.optncsb.inclusion' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.optncsb.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.delayed' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.delayed.nwa' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.direct' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.direct.nwa' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.fair' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.fair.nwa' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.multipebble' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.performance' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.util.nwa' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.util.nwa.graph' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.util.nwa.graph.game' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.util.nwa.graph.summarycomputationgraph' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.operations.simulation.util.old' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.reachablestates' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.senwa' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.transitions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword.visualization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.partialorder' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.partialorder.independence' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.partialorder.independence.abstraction' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.partialorder.multireduction' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.partialorder.visitors' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.petrinet' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.petrinet.netdatastructures' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.petrinet.operations' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.petrinet.petruchio' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.petrinet.unfolding' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.petrinet.visualization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.rabin' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.statefactory' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree.operations' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree.operations.difference' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree.operations.minimization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree.operations.minimization.hopcroft' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree.operations.minimization.performance' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.tree.visualization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.automata' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.structure' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.transitions' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder.cfg' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.automata' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.automata&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.boogieast' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-BoogieAST'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.boogieast'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.ast' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.output' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.type' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.typechecker' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.astbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.boogieast' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.boogieast&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.chc' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.chc' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-TreeAutomizer'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.chc'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.chc' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.chc' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.chc.eldarica' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.chc.results' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.chc' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.chc' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.chc&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.core' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.core' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='de.uni_freiburg.informatik.ultimate.lib.core'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.core'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.core' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.models' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.models.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.observers' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.results' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.toolchain' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.translation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.lib.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.core' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='java.package' name='com.sun.xml.bind.v2' range='2.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.core' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.core&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-IcfgTransformer'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.heapseparator' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.biesenbach' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.fastupr' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.fastupr.paraoct' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.jordan' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.mohr' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.qvasr' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.qvasrs' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.werner' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.loopacceleration.woelfing' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.mapelim.monniaux' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.icfgtransformer.transformulatransformers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.icfgtransformer&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.lassoranker' version='0.9.5' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='[0.0.0,0.9.5)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-LassoRanker'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.lassoranker'/>
        <property name='maven-version' value='0.9.5'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' version='0.9.5'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' version='0.9.5'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.nontermination' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.preprocessors' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.synthesis' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.termination' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.termination.rankingfunctions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.termination.templates' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lassoranker.variables' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' version='0.9.5'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.commons.lang' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.lassoranker' version='0.9.5'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.lassoranker&#xA;Bundle-Version: 0.9.5
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.mcr' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.mcr' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-MCR'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.mcr'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.mcr' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.mcr' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.mcr' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.mcr' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.mcr' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.mcr&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-ModelCheckerUtils'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='27'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.absint' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.absint.vpdomain' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.boogie' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.structure' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.structure.debugidentifiers' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.transformations' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.transitions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.cfg.variables' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.dangerinvariants' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.hoaretriple' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.biesenb' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.equalityanalysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.interpolant' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.mapelimination' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.predicates' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.tracecheck' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.synthesis' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.taskidentifier' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.tracehandling' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.xnf' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='net.sf.javabdd' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.commons.lang' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.mso' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.mso' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-MSO'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.mso'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.mso' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.mso' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.mso' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.mso' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.mso' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.mso&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='de.uni_freiburg.informatik.ultimate.lib.pathexpressions'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.pathexpressions'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions.regex' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.datastructures.relation' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.pathexpressions&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.pdr' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.pdr' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-PDR'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.pdr'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.pdr' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pdr' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pdr' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.pdr' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.pdr' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.pdr&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.pea' version='0.89.0' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.pea' range='[0.0.0,0.89.0)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-PEA'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.pea'/>
        <property name='maven-version' value='0.89.0'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.pea' version='0.89.0'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pea' version='0.89.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.modelchecking' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.modelchecking.armc' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.modelchecking.localize' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.modelchecking.schemas' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.reqcheck' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.test' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.pea.util.z' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.pea' version='0.89.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.jdom' range='0.0.0'/>
        <required namespace='osgi.bundle' name='net.sourceforge.czt' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.xerces.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.xerces.parsers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.pea' version='0.89.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.pea&#xA;Bundle-Version: 0.89.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.preferencejson' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.preferencejson' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='de.uni_freiburg.informatik.ultimate.lib.preferencejson'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.preferencejson'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.preferencejson' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.preferencejson' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.preferencejson' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.preferencejson' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.gson' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.preferencejson' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.preferencejson&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.sifa' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.sifa' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-Sifa'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.sifa'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.sifa' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.sifa' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa.cfgpreprocessing' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa.domain' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa.fluid' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa.regexdag' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa.statistics' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.sifa.summarizers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.sifa' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.sifa' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.sifa&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.smtlib' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='de.uni_freiburg.informatik.ultimate.lib.smtlib'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.smtlib'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.logic' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.logic.simplification' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.smtlib' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.smtlib&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-SmtLibUtils'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.smtlibutils'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils.smt.scripttransfer' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.abduction' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.arrays' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.binaryrelation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.bvinttranslation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.normalforms' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.polynomials' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.quantifier' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.simplify' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils.solverbuilder' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='net.sf.javabdd' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.smtlibutils&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.srparse' version='1.0.0' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.srparse' range='[0.0.0,1.0.0)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-srParse'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.srparse'/>
        <property name='maven-version' value='1.0.0'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.srparse' version='1.0.0'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.srparse' version='1.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.srparse' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.srparse.pattern' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.srparse' version='1.0.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pea' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.astbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.util' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.datastructures.relation' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.srparse' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.srparse;singleton:=true&#xA;Bundle-Version: 1.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-TraceCheckerUtils'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.cfg2automaton' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.initialabstraction' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.partialorder' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.partialorder.independence' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.partialorder.independence.abstraction' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.partialorder.petrinetlbe' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.predicates' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils.singletracecheck' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-UltimateModel'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.models' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.models.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.observers' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.results' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.services' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.core.model.translation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='javax.xml.bind' range='2.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.ultimatemodel&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.lib.util' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.lib.util' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='de.uni_freiburg.informatik.ultimate.lib.util'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.lib.util'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.lib.util' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.csv' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.datastructures' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.datastructures.congruenceclosure' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.datastructures.poset' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.datastructures.relation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.scc' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.statistics' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.util.simplifier' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.lib.util' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.lib.util' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.lib.util&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.ltl2aut' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.ltl2aut' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='LTL2aut'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.ltl2aut'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.ltl2aut' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.ltl2aut' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.ltl2aut.ast' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.ltl2aut.never2nwa' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.ltl2aut' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.parser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.acsl.parser' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.commons.io' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.ltl2aut' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.ltl2aut;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.pea2boogie' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.pea2boogie' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='PEAtoBoogie'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.pea2boogie'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.pea2boogie' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.pea2boogie' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.pea2boogie' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.pea2boogie.results' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.pea2boogie.testgen' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.pea2boogie' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pea' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.srparse' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.pea2boogie' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.pea2boogie;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='AbstractInterpretation'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.algorithm.rcfg' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.domain.nonrelational.dataflow' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.domain.nonrelational.livevariable' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.domain.relational.octagon' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.domain.transformula.vp' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.tool' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.ojalgo' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.parser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='IRSDependencies'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies.loopdetector' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies.rcfg.visitors' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies.rcfg.walker' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.analysis.irsdependencies;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='LassoRanker'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.analysis.lassoranker;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Reaching Definitions'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions.annotations' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions.boogie' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions.dataflowdag' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.logic' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='SyntaxChecker'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.cdt.parser' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.analysis.syntaxchecker;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BlockEncodingV2'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.blockencoding'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding.preferences' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.blockencoding;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ChcSolver'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.chcsolver'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.chcsolver' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.chcsolver;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ChcToBoogie'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.chctoboogie' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.chctoboogie;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='AutomataScriptInterpreter'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BuchiAutomizer'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.buchiautomizer;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='CACSL2BoogieTranslator'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.cdt.translation.implementation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.cdt.translation.implementation.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.acsl.parser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessprinter' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.cdt.parser' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.cacsl2boogietranslator;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='CodeCheck'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.codecheck;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='InvariantSynthesis'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.invariantsynthesis;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Boogie Modifies Set Annotator'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.parser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.modsetannotator;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='RCFGBuilder'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder.cfg' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.printer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.boogie.type' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Referee'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.referee'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.referee' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.referee;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='TraceAbstraction'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.automataminimization' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.benchmark' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.concurrency' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.interpolantautomata.builders' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.interpolantautomata.transitionappender' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.interpolantconsolidation' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.pathinvariants' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.pathinvariants.internal' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.predicates' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.tracehandling' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction.witnesschecking' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.lassoranker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.blockencoding' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.automatascriptinterpreter' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pdr' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.mcr' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.sifa' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.sifa' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.acceleratedinterpolation' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='TraceAbstractionConcurrent'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='TraceAbstractionWithAFAs'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionconcurrent' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.reachingdefinitions' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstractionwithafas;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='TreeAutomizer'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.traceabstraction' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='IcfgToChc'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.tracecheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.icfgtochc' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.icfgtochc;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='IcfgTransformation'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.analysis.abstractinterpretationv2' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.icfgtransformer' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.icfgtransformation;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.sifa' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.sifa' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Sifa'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.sifa'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.sifa' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.sifa' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.sifa' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.sifa' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pathexpressions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.sifa' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.sifa' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.sifa;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='AutomataScriptParser'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser.AST' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.automata' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.plugins.source.automatascriptparser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.req.printer' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.req.printer' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BoogiePrinter Plug-in'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.req.printer'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.req.printer' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.req.printer' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.req.printer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.req.printer' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.pea2boogie' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.srparse' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.req.printer' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.req.printer;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.reqparser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.reqparser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ReqParser'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.reqparser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.reqparser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.reqparser' version='0.2.4'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.reqparser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.srparse' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.reqparser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.reqparser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.reqtotest' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.reqtotest' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='ReqToTest'/>
        <property name='maven-groupId' value='ReqToTest'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.reqtotest'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.reqtotest' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.reqtotest' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.reqtotest' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.reqtotest.req' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.reqtotest' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.pea' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.srparse' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.boogie.preprocessor' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.pea2boogie' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.nestedword' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.automata.statefactory' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.reqtotest' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.reqtotest;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.smtinterpol' version='2.0.0' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.smtinterpol' range='[0.0.0,2.0.0)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='SMTInterpol - an Interpolating SMT Solver'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.smtinterpol'/>
        <property name='maven-version' value='2.0.0'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.smtinterpol' version='2.0.0'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' version='2.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.model' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.muses' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.option' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.proof' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.smtlib' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.smtlib2' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtinterpol.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.smtinterpol' version='2.0.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.smtinterpol' version='2.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.smtinterpol&#xA;Bundle-Version: 2.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.smtsolver.external' version='0.2.4' singleton='false' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='SMTSolverBridge'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.smtsolver.external'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.github.jhoenicke.javacup' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.commons.io' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.smtsolver.external' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.smtsolver.external&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.source.smtparser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.source.smtparser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='SmtParser'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.source.smtparser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.source.smtparser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.source.smtparser' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.source.smtparser' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.source.smtparser.chc' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.source.smtparser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlibutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.chc' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.mso' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtinterpol' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.smtsolver.external' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.boogieast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.treeautomizer' range='0.0.0'/>
        <required namespace='java.package' name='de.uni_freiburg.informatik.ultimate.source.smtparser' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.source.smtparser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.source.smtparser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.witnessparser' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.witnessparser' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='WitnessParser'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.witnessparser'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.witnessparser' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.witnessparser.graph' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.witnessparser.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.witnessparser.yaml' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.witnessparser' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='edu.uci.ics.jung' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.ultimatemodel' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.yaml.snakeyaml' range='2.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.witnessparser' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.witnessparser;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='de.uni_freiburg.informatik.ultimate.witnessprinter' version='0.2.4' generation='2'>
      <update id='de.uni_freiburg.informatik.ultimate.witnessprinter' range='[0.0.0,0.2.4)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='BuchiProgramProduct'/>
        <property name='maven-groupId' value='de.uni_freiburg.informatik.ultimate'/>
        <property name='maven-artifactId' value='de.uni_freiburg.informatik.ultimate.witnessprinter'/>
        <property name='maven-version' value='0.2.4'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.uni_freiburg.informatik.ultimate.witnessprinter' version='0.2.4'/>
        <provided namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessprinter' version='0.2.4'/>
        <provided namespace='java.package' name='de.uni_freiburg.informatik.ultimate.witnessprinter' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.uni_freiburg.informatik.ultimate.witnessprinter' version='0.2.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.smtlib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.lib.modelcheckerutils' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.commons.lang' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='edu.uci.ics.jung' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.plugins.generator.rcfgbuilder' range='0.0.0'/>
        <required namespace='osgi.bundle' name='de.uni_freiburg.informatik.ultimate.witnessparser' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.uni_freiburg.informatik.ultimate.witnessprinter' version='0.2.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.uni_freiburg.informatik.ultimate.witnessprinter;singleton:=true&#xA;Bundle-Version: 0.2.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='edu.uci.ics.jung' version='2.0.1' singleton='false' generation='2'>
      <update id='edu.uci.ics.jung' range='[0.0.0,2.0.1)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Library-Jung'/>
        <property name='org.eclipse.equinox.p2.provider' value='http://jung.sourceforge.net/'/>
        <property name='maven-groupId' value='edu.uci.ics.jung'/>
        <property name='maven-artifactId' value='edu.uci.ics.jung'/>
        <property name='maven-version' value='2.0.1'/>
      </properties>
      <provides size='108'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='edu.uci.ics.jung' version='2.0.1'/>
        <provided namespace='osgi.bundle' name='edu.uci.ics.jung' version='2.0.1'/>
        <provided namespace='java.package' name='cern.clhep' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.bitvector' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.buffer' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.function' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.list' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.list.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.map' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.matrix' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.matrix.bench' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.matrix.doublealgo' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.matrix.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.matrix.linalg' version='0.0.0'/>
        <provided namespace='java.package' name='cern.colt.matrix.objectalgo' version='0.0.0'/>
        <provided namespace='java.package' name='cern.jet.math' version='0.0.0'/>
        <provided namespace='java.package' name='cern.jet.random' version='0.0.0'/>
        <provided namespace='java.package' name='cern.jet.random.engine' version='0.0.0'/>
        <provided namespace='java.package' name='cern.jet.random.sampling' version='0.0.0'/>
        <provided namespace='java.package' name='cern.jet.stat' version='0.0.0'/>
        <provided namespace='java.package' name='cern.jet.stat.quantile' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.api' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.cfg' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.compat' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.dom' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.dtd' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.ent' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.evt' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.exc' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.io' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.msv' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.sax' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.sr' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.stax' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.sw' version='0.0.0'/>
        <provided namespace='java.package' name='com.ctc.wstx.util' version='0.0.0'/>
        <provided namespace='java.package' name='corejava' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.blockmodel' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.cluster' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.filters' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.flows' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.generators' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.generators.random' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.importance' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.layout' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.layout.util' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.layout3d' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.matrix' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.metrics' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.scoring' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.scoring.util' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.shortestpath' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.transformation' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.algorithms.util' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.graph' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.graph.event' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.graph.util' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.io' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.io.graphml' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.io.graphml.parser' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.samples' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.annotations' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.control' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.decorators' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.jai' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.layout' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.picking' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.renderers' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.subLayout' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.transform' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.transform.shape' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization.util' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization3d' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization3d.control' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization3d.decorators' version='0.0.0'/>
        <provided namespace='java.package' name='edu.uci.ics.jung.visualization3d.layout' version='0.0.0'/>
        <provided namespace='java.package' name='hep.aida' version='0.0.0'/>
        <provided namespace='java.package' name='hep.aida.bin' version='0.0.0'/>
        <provided namespace='java.package' name='hep.aida.ref' version='0.0.0'/>
        <provided namespace='java.package' name='javax.media.j3d' version='0.0.0'/>
        <provided namespace='java.package' name='javax.vecmath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.bag' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.bidimap' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.buffer' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.collection' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.comparators' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.functors' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.iterators' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.keyvalue' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.multimap' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.collections15.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.stax2' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.stax2.evt' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.stax2.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.stax2.ri' version='0.0.0'/>
        <provided namespace='java.package' name='org.codehaus.stax2.validation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='edu.uci.ics.jung' version='2.0.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='edu.uci.ics.jung' version='2.0.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: edu.uci.ics.jung&#xA;Bundle-Version: 2.0.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.activation' version='1.1.0.v201211130549' singleton='false'>
      <update id='javax.activation' range='[0.0.0,1.1.0.v201211130549)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='Apache Geronimo Activation Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='2248'/>
        <property name='iplog.contact.name' value='David Williams'/>
        <property name='iplog.contact.email' value='david_williams@us.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.activation' version='1.1.0.v201211130549'/>
        <provided namespace='osgi.bundle' name='javax.activation' version='1.1.0.v201211130549'/>
        <provided namespace='java.package' name='javax.activation' version='1.1.0'/>
        <provided namespace='java.package' name='org.apache.geronimo.activation.handlers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.metadata' range='0.0.0'/>
        <required namespace='java.package' name='javax.mail' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.mail.internet' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.activation' version='1.1.0.v201211130549'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.activation&#xA;Bundle-Version: 1.1.0.v201211130549
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.annotation' version='1.3.5.v20200504-1837' singleton='false' generation='2'>
      <update id='javax.annotation' range='[0.0.0,1.3.5.v20200504-1837)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Jakarta Annotations API'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Jakarta Annotations API'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='javax.annotation'/>
        <property name='maven-version' value='1.3.5-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.annotation' version='1.3.5.v20200504-1837'/>
        <provided namespace='osgi.bundle' name='javax.annotation' version='1.3.5.v20200504-1837'/>
        <provided namespace='java.package' name='javax.annotation' version='1.3.5'/>
        <provided namespace='java.package' name='javax.annotation.security' version='1.3.5'/>
        <provided namespace='java.package' name='javax.annotation.sql' version='1.3.5'/>
        <provided namespace='osgi.identity' name='javax.annotation' version='1.3.5.v20200504-1837'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.annotation' version='1.3.5.v20200504-1837'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.annotation&#xA;Bundle-Version: 1.3.5.v20200504-1837
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.inject' version='1.0.0.v20091030' singleton='false'>
      <update id='javax.inject' range='[0.0.0,1.0.0.v20091030)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='Atinject Dependency Injection Annotations'/>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='iplog.bug_id' value='3555'/>
        <property name='iplog.contact.name' value='Boris Bokowski'/>
        <property name='iplog.contact.email' value='Boris_Bokowski@ca.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.inject' version='1.0.0.v20091030'/>
        <provided namespace='osgi.bundle' name='javax.inject' version='1.0.0.v20091030'/>
        <provided namespace='java.package' name='javax.inject' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.inject' version='1.0.0.v20091030'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.inject&#xA;Bundle-Version: 1.0.0.v20091030
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.xml' version='1.3.4.v201005080400' singleton='false'>
      <update id='javax.xml' range='[0.0.0,1.3.4.v201005080400)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='JAXP XML'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='29'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.xml' version='1.3.4.v201005080400'/>
        <provided namespace='osgi.bundle' name='javax.xml' version='1.3.4.v201005080400'/>
        <provided namespace='java.package' name='javax.xml' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='1.3.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.xmlcommons' version='1.3.4'/>
        <provided namespace='java.package' name='org.w3c.dom' version='3.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='3.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='2.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='3.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='2.0.2'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='2.0.2'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='2.0.2'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.xml' version='1.3.4.v201005080400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.xml&#xA;Bundle-Version: 1.3.4.v201005080400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.xml.bind' version='2.2.0.v201105210648' singleton='false'>
      <update id='javax.xml.bind' range='[0.0.0,2.2.0.v201105210648)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='XML Binding for Java'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='3842'/>
        <property name='iplog.contact.name' value='Blaise Doughan'/>
        <property name='iplog.contact.email' value='blaise.doughan@oracle.com'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.xml.bind' version='2.2.0.v201105210648'/>
        <provided namespace='osgi.bundle' name='javax.xml.bind' version='2.2.0.v201105210648'/>
        <provided namespace='java.package' name='javax.xml.bind' version='2.2.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation' version='2.2.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation.adapters' version='2.2.0'/>
        <provided namespace='java.package' name='javax.xml.bind.attachment' version='2.2.0'/>
        <provided namespace='java.package' name='javax.xml.bind.helpers' version='2.2.0'/>
        <provided namespace='java.package' name='javax.xml.bind.util' version='2.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='javax.xml' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='javax.activation' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.xml.stream' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.xml.bind' version='2.2.0.v201105210648'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.xml.bind&#xA;Bundle-Version: 2.2.0.v201105210648
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.xml.stream' version='1.0.1.v201004272200' singleton='false'>
      <update id='javax.xml.stream' range='[0.0.0,1.0.1.v201004272200)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.Bundle-Name' value='Java XML Streaming API'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='iplog.bug_id' value='3003'/>
        <property name='iplog.contact.name' value='Oisin Hurley'/>
        <property name='iplog.contact.email' value='oisin.hurley@gmail.com'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.xml.stream' version='1.0.1.v201004272200'/>
        <provided namespace='osgi.bundle' name='javax.xml.stream' version='1.0.1.v201004272200'/>
        <provided namespace='java.package' name='javax.xml' version='1.0.1'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='1.0.1'/>
        <provided namespace='java.package' name='javax.xml.stream' version='1.0.1'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='1.0.1'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='1.0.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='javax.xml' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.xml.stream' version='1.0.1.v201004272200'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.xml.stream&#xA;Bundle-Version: 1.0.1.v201004272200
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='net.sf.javabdd' version='0.6.0' singleton='false' generation='2'>
      <update id='net.sf.javabdd' range='[0.0.0,0.6.0)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Library-JavaBDD'/>
        <property name='org.eclipse.equinox.p2.provider' value='http://javabdd.sourceforge.net/'/>
        <property name='maven-groupId' value='net.sf.javabdd'/>
        <property name='maven-artifactId' value='net.sf.javabdd'/>
        <property name='maven-version' value='0.6.0'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='net.sf.javabdd' version='0.6.0'/>
        <provided namespace='osgi.bundle' name='net.sf.javabdd' version='0.6.0'/>
        <provided namespace='java.package' name='net.sf.javabdd' version='0.0.0'/>
        <provided namespace='osgi.identity' name='net.sf.javabdd' version='0.6.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='net.sf.javabdd' version='0.6.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: net.sf.javabdd&#xA;Bundle-Version: 0.6.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='net.sourceforge.czt' version='1.5.0' singleton='false' generation='2'>
      <update id='net.sourceforge.czt' range='[0.0.0,1.5.0)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-CZT'/>
        <property name='maven-groupId' value='net.sourceforge.czt'/>
        <property name='maven-artifactId' value='net.sourceforge.czt'/>
        <property name='maven-version' value='1.5.0'/>
      </properties>
      <provides size='109'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='net.sourceforge.czt' version='1.5.0'/>
        <provided namespace='osgi.bundle' name='net.sourceforge.czt' version='1.5.0'/>
        <provided namespace='java.package' name='junit.extensions' version='0.0.0'/>
        <provided namespace='java.package' name='junit.framework' version='0.0.0'/>
        <provided namespace='java.package' name='junit.runner' version='0.0.0'/>
        <provided namespace='java.package' name='junit.textui' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.animation.eval' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.animation.eval.flatpred' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.animation.eval.flatvisitor' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.animation.eval.result' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.base.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.base.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.base.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.base.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.base.visitor' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circus.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circus.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circus.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circus.jaxb.gen' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circus.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circus.visitor' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circuspatt.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circuspatt.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circuspatt.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circuspatt.jaxb.gen' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circuspatt.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.circuspatt.visitor' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.dc.z' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.oz.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.oz.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.oz.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.oz.jaxb.gen' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.oz.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.oz.visitor' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.parser.circus' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.parser.oz' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.parser.ozpatt' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.parser.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.parser.z' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.parser.zpatt' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.print.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.print.circus' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.print.oz' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.print.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.print.z' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.print.zpatt' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.oldrewriter' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.oracles' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.print' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.prover' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.rewriter' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.rules.unification' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.session' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.specreader' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.circus' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.circus.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.circus.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.oz' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.oz.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.oz.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.z' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.z.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.typecheck.z.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.ui' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.z.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.z.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.z.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.z.jaxb.gen' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.z.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.z.visitor' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zeves' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zeves.proof' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zeves.response' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zeves.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zeves.z' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zml' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zpatt.ast' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zpatt.impl' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zpatt.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zpatt.jaxb.gen' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zpatt.util' version='0.0.0'/>
        <provided namespace='java.package' name='net.sourceforge.czt.zpatt.visitor' version='0.0.0'/>
        <provided namespace='java.package' name='org.hamcrest' version='0.0.0'/>
        <provided namespace='java.package' name='org.hamcrest.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.hamcrest.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.experimental.results' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.experimental.runners' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.experimental.theories' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.experimental.theories.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.experimental.theories.suppliers' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal.builders' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal.matchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal.requests' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal.runners' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal.runners.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.internal.runners.statements' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.matchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.runner' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.runner.manipulation' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.runner.notification' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.runners' version='0.0.0'/>
        <provided namespace='java.package' name='org.junit.runners.model' version='0.0.0'/>
        <provided namespace='osgi.identity' name='net.sourceforge.czt' version='1.5.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='net.sourceforge.czt' version='1.5.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: net.sourceforge.czt&#xA;Bundle-Version: 1.5.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.constants' version='1.13.0.v20200622-2037' singleton='false' generation='2'>
      <update id='org.apache.batik.constants' range='[0.0.0,1.13.0.v20200622-2037)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Batik constants library'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.batik.constants'/>
        <property name='maven-version' value='1.13.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.constants' version='1.13.0.v20200622-2037'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.constants' version='1.13.0.v20200622-2037'/>
        <provided namespace='java.package' name='org.apache.batik.constants' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.util' version='1.13.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.constants' version='1.13.0.v20200622-2037'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.constants' version='1.13.0.v20200622-2037'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.constants&#xA;Bundle-Version: 1.13.0.v20200622-2037
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.css' version='1.13.0.v20200622-2037' singleton='false' generation='2'>
      <update id='org.apache.batik.css' range='[0.0.0,1.13.0.v20200622-2037)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Batik CSS engine'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.batik.css'/>
        <property name='maven-version' value='1.13.0-SNAPSHOT'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.css' version='1.13.0.v20200622-2037'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.css' version='1.13.0.v20200622-2037'/>
        <provided namespace='java.package' name='org.apache.batik.css.dom' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.resources' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.sac' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.css2' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.resources' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.svg' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.engine.value.svg12' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.parser' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.css.parser.resources' version='1.13.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.css' version='1.13.0.v20200622-2037'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.apache.batik.util' range='1.13.0'/>
        <required namespace='osgi.bundle' name='org.apache.batik.constants' range='1.13.0'/>
        <required namespace='java.package' name='org.apache.batik.css.engine' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.css.engine.sac' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.css.engine.value' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.css.engine.value.css2' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.css.engine.value.svg' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.css.engine.value.svg12' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.css.parser' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.i18n' range='1.13.0'/>
        <required namespace='java.package' name='org.apache.batik.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.util.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d.color' range='2.2.0'/>
        <required namespace='java.package' name='org.w3c.css.sac' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.events' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.svg' range='1.1.0'/>
        <required namespace='java.package' name='org.w3c.dom.views' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.css' version='1.13.0.v20200622-2037'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.css&#xA;Bundle-Version: 1.13.0.v20200622-2037
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.i18n' version='1.13.0.v20200622-2037' singleton='false' generation='2'>
      <update id='org.apache.batik.i18n' range='[0.0.0,1.13.0.v20200622-2037)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Batik i18n library'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.batik.i18n'/>
        <property name='maven-version' value='1.13.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.i18n' version='1.13.0.v20200622-2037'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.i18n' version='1.13.0.v20200622-2037'/>
        <provided namespace='java.package' name='org.apache.batik.i18n' version='1.13.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.i18n' version='1.13.0.v20200622-2037'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.i18n' version='1.13.0.v20200622-2037'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.i18n&#xA;Bundle-Version: 1.13.0.v20200622-2037
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.batik.util' version='1.13.0.v20200622-2037' singleton='false' generation='2'>
      <update id='org.apache.batik.util' range='[0.0.0,1.13.0.v20200622-2037)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Batik utility library'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.batik.util'/>
        <property name='maven-version' value='1.13.0-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.batik.util' version='1.13.0.v20200622-2037'/>
        <provided namespace='osgi.bundle' name='org.apache.batik.util' version='1.13.0.v20200622-2037'/>
        <provided namespace='java.package' name='org.apache.batik' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.util' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.util.io' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.util.io.resources' version='1.13.0'/>
        <provided namespace='java.package' name='org.apache.batik.util.resources' version='1.13.0'/>
        <provided namespace='osgi.identity' name='org.apache.batik.util' version='1.13.0.v20200622-2037'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.apache.batik.constants' range='1.13.0'/>
        <required namespace='java.package' name='org.apache.batik' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.constants' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.i18n' range='1.13.0'/>
        <required namespace='java.package' name='org.apache.batik.util' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.batik.util.resources' range='[1.13.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.batik.util' version='1.13.0.v20200622-2037'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.batik.util&#xA;Bundle-Version: 1.13.0.v20200622-2037
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.cli' version='1.3.1' singleton='false' generation='2'>
      <update id='org.apache.commons.cli' range='[0.0.0,1.3.1)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Library-ApacheCommonsCLI'/>
        <property name='org.eclipse.equinox.p2.provider' value='http://commons.apache.org'/>
        <property name='maven-groupId' value='org.apache.commons'/>
        <property name='maven-artifactId' value='org.apache.commons.cli'/>
        <property name='maven-version' value='1.3.1'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.cli' version='1.3.1'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.cli' version='1.3.1'/>
        <provided namespace='java.package' name='org.apache.commons.cli' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.cli' version='1.3.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.cli' version='1.3.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.cli&#xA;Bundle-Version: 1.3.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.io' version='2.6.0.v20190123-2029' singleton='false' generation='2'>
      <update id='org.apache.commons.io' range='[0.0.0,2.6.0.v20190123-2029)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons IO'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Apache Commons IO library contains utility classes, stream implementations, file filters,file comparators, endian transformation classes, and much more.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://commons.apache.org/proper/commons-io/'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.commons.io'/>
        <property name='maven-version' value='2.6.0-SNAPSHOT'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.io' version='2.6.0.v20190123-2029'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.io' version='2.6.0.v20190123-2029'/>
        <provided namespace='java.package' name='org.apache.commons.io' version='2.6.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.comparator' version='2.6.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.filefilter' version='2.6.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.input' version='2.6.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.monitor' version='2.6.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.output' version='2.6.0'/>
        <provided namespace='java.package' name='org.apache.commons.io.serialization' version='2.6.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.io' version='2.6.0.v20190123-2029'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.apache.commons.io' range='[2.6.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.io.comparator' range='[2.6.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.io.filefilter' range='[2.6.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.io.input' range='[2.6.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.io.output' range='[2.6.0,3.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.io' version='2.6.0.v20190123-2029'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.io&#xA;Bundle-Version: 2.6.0.v20190123-2029
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.jxpath' version='1.3.0.v200911051830' singleton='false'>
      <update id='org.apache.commons.jxpath' range='[0.0.0,1.3.0.v200911051830)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Apache Commons JXPath'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='3264'/>
        <property name='iplog.contact.name' value='Mike Squillace'/>
        <property name='iplog.contact.email' value='masquill@us.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.jxpath' version='1.3.0.v200911051830'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.jxpath' version='1.3.0.v200911051830'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.functions' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.axes' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.compiler' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model.beans' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model.container' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model.dom' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model.dynabeans' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model.dynamic' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.model.jdom' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.ri.parser' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.servlet' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.util' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.jxpath.xml' version='1.3.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.jxpath' version='1.3.0.v200911051830'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.jxpath&#xA;Bundle-Version: 1.3.0.v200911051830
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.lang' version='3.12.0' singleton='false' generation='2'>
      <update id='org.apache.commons.lang' range='[0.0.0,3.12.0)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Library-ApacheCommonsLang'/>
        <property name='org.eclipse.equinox.p2.provider' value='https://commons.apache.org/proper/commons-lang'/>
        <property name='maven-groupId' value='org.apache.commons'/>
        <property name='maven-artifactId' value='org.apache.commons.lang'/>
        <property name='maven-version' value='3.12.0'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.lang' version='3.12.0'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.lang' version='3.12.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.arch' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.builder' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.compare' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.exception' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.function' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.math' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.mutable' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.stream' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.text.translate' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.time' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang3.tuple' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.lang' version='3.12.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.lang' version='3.12.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.lang&#xA;Bundle-Version: 3.12.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.logging' version='1.2.0.v20180409-1502' singleton='false'>
      <update id='org.apache.commons.logging' range='[0.0.0,1.2.0.v20180409-1502)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Logging'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Commons Logging is a thin adapter allowing configurable bridging to other,    well known logging systems.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://commons.apache.org/proper/commons-logging/'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.commons.logging'/>
        <property name='maven-version' value='1.2.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' version='1.2.0.v20180409-1502'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.logging' version='1.2.0.v20180409-1502'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.avalon.framework.logger' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.logging.impl' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.logging' version='1.2.0.v20180409-1502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.logging&#xA;Bundle-Version: 1.2.0.v20180409-1502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.1.16.v20200110-1820' singleton='false' generation='2'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.1.16.v20200110-1820)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.4'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.felix.scr'/>
        <property name='maven-version' value='2.1.16-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.1.16.v20200110-1820'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.1.16.v20200110-1820'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.scr' version='2.1.16.v20200110-1820'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.component' version='1.4.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.scr_2.1.16.v20200110-1820-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.component.runtime.ServiceComponentRuntime' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.apache.felix.shell' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.1.16.v20200110-1820'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.1.16.v20200110-1820
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.log4j' version='1.2.15.v201012070815' singleton='false'>
      <update id='org.apache.log4j' range='[0.0.0,1.2.15.v201012070815)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.PLUGIN_NAME' value='Apache Jakarta log4j Plug-in'/>
        <property name='df_LT.PLUGIN_PROVIDER' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%PLUGIN_NAME'/>
        <property name='org.eclipse.equinox.p2.provider' value='%PLUGIN_PROVIDER'/>
        <property name='iplog.bug_id' value='3560'/>
        <property name='iplog.contact.name' value='David Williams'/>
        <property name='iplog.contact.email' value='david_williams@us.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='23'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j' version='1.2.15.v201012070815'/>
        <provided namespace='osgi.bundle' name='org.apache.log4j' version='1.2.15.v201012070815'/>
        <provided namespace='java.package' name='org.apache.log4j' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.chainsaw' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.config' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.helpers' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.jdbc' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.jmx' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.util' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.viewer' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.viewer.categoryexplorer' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.lf5.viewer.configure' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.net' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.nt' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.or' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.or.jms' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.or.sax' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.spi' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.varia' version='1.2.15'/>
        <provided namespace='java.package' name='org.apache.log4j.xml' version='1.2.15'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.log4j' version='1.2.15.v201012070815'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.log4j&#xA;Bundle-Version: 1.2.15.v201012070815
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.logging.log4j' version='2.8.2.v20200818-1118' singleton='false' generation='2'>
      <update id='org.apache.logging.log4j' range='[0.0.0,2.8.2.v20200818-1118)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Log4j 2'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Apache Log4j Implementation'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.logging.log4j'/>
        <property name='maven-version' value='2.8.2-SNAPSHOT'/>
      </properties>
      <provides size='59'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.logging.log4j' version='2.8.2.v20200818-1118'/>
        <provided namespace='osgi.bundle' name='org.apache.logging.log4j' version='2.8.2.v20200818-1118'/>
        <provided namespace='java.package' name='org.apache.logging.log4j' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.db' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.db.jdbc' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.db.jpa' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.db.jpa.converter' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.mom' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.mom.jeromq' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.mom.kafka' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.rewrite' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.rolling' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.rolling.action' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.appender.routing' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.async' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.builder.api' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.builder.impl' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.composite' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.json' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.convert' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.processor' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.util' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.validation' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.validation.constraints' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.validation.validators' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.visitors' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.properties' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.status' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.xml' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.config.yaml' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.filter' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.impl' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.jackson' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.jmx' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.layout' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.lookup' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.net' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.net.mom.jms' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.net.server' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.net.ssl' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.osgi' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.pattern' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.script' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.selector' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.tools' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.util' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.core.util.datetime' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.message' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.simple' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.spi' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.status' version='2.8.2'/>
        <provided namespace='java.package' name='org.apache.logging.log4j.util' version='2.8.2'/>
        <provided namespace='osgi.identity' name='org.apache.logging.log4j' version='2.8.2.v20200818-1118'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='102'>
        <required namespace='java.package' name='com.beust.jcommander' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.beust.jcommander.validators' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.conversantmedia.util.concurrent' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.annotation' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.core' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.core.type' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.core.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.annotation' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.deser.std' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.module' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.node' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.ser' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.ser.impl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.databind.ser.std' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.dataformat.xml' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.dataformat.xml.annotation' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.dataformat.xml.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.fasterxml.jackson.dataformat.yaml' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.lmax.disruptor' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.lmax.disruptor.dsl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.activation' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.annotation.processing' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.jms' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.lang.model' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.lang.model.element' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.lang.model.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.mail' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.mail.internet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.mail.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.management' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.persistence' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.script' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.sql' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.tools' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.bind' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.stream' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.validation' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.compress.compressors' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.compress.utils' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.csv' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.kafka.clients.producer' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender.db' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender.db.jpa.converter' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender.mom' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender.rewrite' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender.rolling' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.appender.rolling.action' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.async' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.builder.api' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.builder.impl' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.composite' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.json' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.convert' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.processor' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.util' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.validation' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.validation.constraints' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.validation.validators' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.plugins.visitors' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.status' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.config.xml' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.filter' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.impl' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.jackson' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.jmx' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.layout' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.lookup' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.net' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.net.server' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.net.ssl' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.pattern' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.script' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.selector' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.util' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.core.util.datetime' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.message' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.simple' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.spi' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.status' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.util' range='[2.8.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.codehaus.stax2' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.fusesource.jansi' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jctools.queues' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.zeromq' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.logging.log4j' version='2.8.2.v20200818-1118'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.logging.log4j&#xA;Bundle-Version: 2.8.2.v20200818-1118
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.xerces' version='2.9.0.v201101211617' singleton='false'>
      <update id='org.apache.xerces' range='[0.0.0,2.9.0.v201101211617)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='Apache Xerces-J'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='2095'/>
        <property name='iplog.contact.name' value='David Williams'/>
        <property name='iplog.contact.email' value='david_williams@us.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='43'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.xerces' version='2.9.0.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.xerces' version='2.9.0.v201101211617'/>
        <provided namespace='java.package' name='META-INF.services' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.html.dom' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.wml' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.wml.dom' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.dom' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.dom.events' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.dom3.as' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.dtd' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.dtd.models' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.dv' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.dv.dtd' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.dv.util' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.dv.xs' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.io' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.msg' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.validation' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xpath' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xpath.regex' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xs' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xs.identity' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xs.models' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xs.opti' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xs.traversers' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.impl.xs.util' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.jaxp' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.jaxp.datatype' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.jaxp.validation' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.parsers' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.util' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xinclude' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xni' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xni.grammars' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xni.parser' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xpointer' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xs' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xerces.xs.datatypes' version='2.9.0'/>
        <provided namespace='java.package' name='org.apache.xml.serialize' version='2.9.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='2.9.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
        <required namespace='osgi.bundle' name='javax.xml' range='[1.3.4,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.xml.resolver' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.xml.serializer' range='[2.7.1,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.xerces' version='2.9.0.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.xerces&#xA;Bundle-Version: 2.9.0.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.xml.resolver' version='1.2.0.v201005080400' singleton='false'>
      <update id='org.apache.xml.resolver' range='[0.0.0,1.2.0.v201005080400)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='Apache XmlResolver'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='2136'/>
        <property name='iplog.contact.name' value='David Williams'/>
        <property name='iplog.contact.email' value='david_williams@us.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.xml.resolver' version='1.2.0.v201005080400'/>
        <provided namespace='osgi.bundle' name='org.apache.xml.resolver' version='1.2.0.v201005080400'/>
        <provided namespace='java.package' name='org.apache.env' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.xml.resolver' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.xml.resolver.apps' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.xml.resolver.etc' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.xml.resolver.helpers' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.xml.resolver.readers' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.xml.resolver.tools' version='1.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.xml.resolver' version='1.2.0.v201005080400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.xml.resolver&#xA;Bundle-Version: 1.2.0.v201005080400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.xml.serializer' version='2.7.1.v201005080400' singleton='false'>
      <update id='org.apache.xml.serializer' range='[0.0.0,2.7.1.v201005080400)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='Apache XML Commons Serializer'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='2134'/>
        <property name='iplog.contact.name' value='David Williams'/>
        <property name='iplog.contact.email' value='david_williams@us.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.xml.serializer' version='2.7.1.v201005080400'/>
        <provided namespace='osgi.bundle' name='org.apache.xml.serializer' version='2.7.1.v201005080400'/>
        <provided namespace='java.package' name='org.apache.xml.serializer' version='2.7.1'/>
        <provided namespace='java.package' name='org.apache.xml.serializer.dom3' version='2.7.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.xml.serializer' version='2.7.1.v201005080400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.xml.serializer&#xA;Bundle-Version: 2.7.1.v201005080400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.xmlgraphics' version='2.4.0.v20200622-2037' singleton='false' generation='2'>
      <update id='org.apache.xmlgraphics' range='[0.0.0,2.4.0.v20200622-2037)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache XML Graphics Commons'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.xmlgraphics'/>
        <property name='maven-version' value='2.4.0-SNAPSHOT'/>
      </properties>
      <provides size='40'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.xmlgraphics' version='2.4.0.v20200622-2037'/>
        <provided namespace='osgi.bundle' name='org.apache.xmlgraphics' version='2.4.0.v20200622-2037'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.fonts' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec.png' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec.tiff' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.codec.util' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.cache' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.impl' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.impl.imageio' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.pipeline' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.spi' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.loader.util' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.rendered' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.writer' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.writer.imageio' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.image.writer.internal' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.io' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d.color' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d.color.profile' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.java2d.ps' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps.dsc' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.events' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.tools' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.dijkstra' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.i18n' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.io' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.util.uri' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp.merge' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas' version='2.4.0'/>
        <provided namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas.pdf' version='2.4.0'/>
        <provided namespace='osgi.identity' name='org.apache.xmlgraphics' version='2.4.0.v20200622-2037'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='46'>
        <required namespace='java.package' name='javax.imageio' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.imageio.event' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.imageio.metadata' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.imageio.plugins.jpeg' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.imageio.spi' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.imageio.stream' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform.sax' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.io' range='1.3.1'/>
        <required namespace='java.package' name='org.apache.commons.io.output' range='1.3.1'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.0.4,1.3.0)'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.fonts' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.codec.png' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.codec.tiff' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.codec.util' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.cache' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.impl' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.pipeline' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.spi' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.loader.util' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.rendered' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.image.writer' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.io' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d.color' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.java2d.color.profile' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps.dsc' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.events' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.ps.dsc.tools' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util.dijkstra' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util.i18n' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.util.io' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp.merge' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xmlgraphics.xmp.schemas.pdf' range='[2.4.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.xmlgraphics' version='2.4.0.v20200622-2037'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.xmlgraphics&#xA;Bundle-Version: 2.4.0.v20200622-2037
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.build.gcc.core' version='1.1.0.202008310002' generation='2'>
      <update id='org.eclipse.cdt.build.gcc.core' range='[0.0.0,1.1.0.202008310002)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='GCC support for CDT Build Core'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.build.gcc.core'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.build.gcc.core' version='1.1.0.202008310002'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.build.gcc.core' version='1.1.0.202008310002'/>
        <provided namespace='java.package' name='org.eclipse.cdt.build.gcc.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.build.gcc.core.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.build.gcc.core' version='1.1.0.202008310002'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='5.12.0'/>
        <required namespace='osgi.bundle' name='com.google.gson' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.build.gcc.core' version='1.1.0.202008310002'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.build.gcc.core;singleton:=true&#xA;Bundle-Version: 1.1.0.202008310002
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core' version='7.0.1.202010091427' generation='2'>
      <update id='org.eclipse.cdt.core' range='[0.0.0,7.0.1.202010091427)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='C/C++ Development Tools Core'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core'/>
        <property name='maven-version' value='7.0.1-SNAPSHOT'/>
      </properties>
      <provides size='107'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core' version='7.0.1.202010091427'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core' version='7.0.1.202010091427'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.build' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.cdtvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.gnu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.gnu.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.gnu.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.ms' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.ast.tag' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.parser.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.parser.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.dom.rewrite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.errorparsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.index.export' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.index.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.language.settings.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.parser.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.parser.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model.extension.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.settings.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.templateengine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.templateengine.process' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core.templateengine.process.processes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.doxygen' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.doxygen.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.cdtvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.ast.tag' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.parser.cpp.semantics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.astwriter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.changegenerator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.commenthandler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.dom.rewrite.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.composite.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.composite.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.index.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.indexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.language' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.language.settings.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.model.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.problem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.scanner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.token' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.parser.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.db' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.dom.c' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.dom.cpp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.export' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.indexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.pdom.tag' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.settings.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.errorparsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.formatter.align' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.internal.formatter.scanner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.cdtvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.coff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.coff.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug.dwarf' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug.stabs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.debug.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.elf' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.elf.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.macho' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.macho.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.som' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.som.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.xcoff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.xcoff.parser' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.core' version='7.0.1.202010091427'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core.native' range='[6.0.0,7.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.7.400,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.6.500,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.6.700,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.7.500,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.13.500,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.16.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.4.600,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.10.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi.services' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='com.google.gson' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.annotation' range='[2.0.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.bind' range='2.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core' version='7.0.1.202010091427'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core; singleton:=true&#xA;Bundle-Version: 7.0.1.202010091427
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core.linux' version='6.0.0.202008310002' generation='2'>
      <update id='org.eclipse.cdt.core.linux' range='[0.0.0,6.0.0.202008310002)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='df_LT.fragmentName.linux' value='C/C++ Development Tools Core for Linux'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName.linux'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core.linux'/>
        <property name='maven-version' value='6.0.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.linux' version='6.0.0.202008310002'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core.linux' version='6.0.0.202008310002'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.core.linux' version='6.0.0.202008310002'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.cdt.core.native' version='6.0.0.202008310002'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core.native' range='[6.0.0,7.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <filter>
        (osgi.os=linux)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core.linux' version='6.0.0.202008310002'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core.linux; singleton:=true&#xA;Bundle-Version: 6.0.0.202008310002&#xA;Fragment-Host: org.eclipse.cdt.core.native;bundle-version=&quot;[6.0.0,7.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core.linux.x86_64' version='6.0.0.202008310002'>
      <update id='org.eclipse.cdt.core.linux.x86_64' range='[0.0.0,6.0.0.202008310002)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.fragmentName.linux.x86_64' value='C/C++ Development Tools Core for Linux x86_64'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName.linux.x86_64'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core.linux.x86_64'/>
        <property name='maven-version' value='6.0.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.linux.x86_64' version='6.0.0.202008310002'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core.linux.x86_64' version='6.0.0.202008310002'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.core.linux.x86_64' version='6.0.0.202008310002'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.cdt.core.native' version='6.0.0.202008310002'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core.native' range='[6.0.0,7.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core.linux.x86_64' version='6.0.0.202008310002'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core.linux.x86_64;singleton:=true&#xA;Bundle-Version: 6.0.0.202008310002&#xA;Fragment-Host: org.eclipse.cdt.core.native;bundle-version=&quot;[6.0.0,7.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.core.native' version='6.0.0.202009030027' generation='2'>
      <update id='org.eclipse.cdt.core.native' range='[0.0.0,6.0.0.202009030027)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='C/C++ Development Tools Core Native Utilities'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.core.native'/>
        <property name='maven-version' value='6.0.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.core.native' version='6.0.0.202009030027'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.core.native' version='6.0.0.202009030027'/>
        <provided namespace='java.package' name='org.eclipse.cdt.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.pty' version='5.7.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.utils.spawner' version='5.7.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.core.native' version='6.0.0.202009030027'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.1.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.core.native' version='6.0.0.202009030027'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.core.native;singleton:=true&#xA;Bundle-Version: 6.0.0.202009030027
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.make.core' version='7.5.0.202009040332' generation='2'>
      <update id='org.eclipse.cdt.make.core' range='[0.0.0,7.5.0.202009040332)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='C/C++ Standard make Build Core'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.make.core'/>
        <property name='maven-version' value='7.5.0-SNAPSHOT'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.make.core' version='7.5.0.202009040332'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.make.core' version='7.5.0.202009040332'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.core.makefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.core.makefile.gnu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.core.scannerconfig' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.makefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.makefile.gnu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.makefile.posix' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.scannerconfig' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.scannerconfig.gnu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.scannerconfig.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.scannerconfig.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.make.internal.core.scannerconfig2' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.make.core' version='7.5.0.202009040332'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[7.0.0,8.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.2.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.tools.templates.core' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.tools.templates.freemarker' range='1.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.make.core' version='7.5.0.202009040332'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.make.core; singleton:=true&#xA;Bundle-Version: 7.5.0.202009040332
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cdt.managedbuilder.core' version='9.0.0.202009010132' generation='2'>
      <update id='org.eclipse.cdt.managedbuilder.core' range='[0.0.0,9.0.0.202009010132)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='CDT Build System Core'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.cdt.managedbuilder.core'/>
        <property name='maven-version' value='9.0.0-SNAPSHOT'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cdt.managedbuilder.core' version='9.0.0.202009010132'/>
        <provided namespace='osgi.bundle' name='org.eclipse.cdt.managedbuilder.core' version='9.0.0.202009010132'/>
        <provided namespace='java.package' name='org.eclipse.cdt.build.core.scannerconfig' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.build.internal.core.scannerconfig' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.build.internal.core.scannerconfig2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.buildmodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.buildproperties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.buildmodel' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.dataprovider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.envvar' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.language.settings.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.macros' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.internal.scannerconfig' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.language.settings.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.macros' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.makegen' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.makegen.gnu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.makegen.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.pdomdepgen' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.projectconverter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.scannerconfig' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.tcmodification' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.templateengine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.managedbuilder.templateengine.processes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.cdt.newmake.core' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.cdt.managedbuilder.core' version='9.0.0.202009010132'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.core' range='[7.0.0,8.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.cdt.make.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.2.0'/>
        <required namespace='java.package' name='com.google.gson' range='2.8.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.cdt.managedbuilder.core' version='9.0.0.202009010132'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.cdt.managedbuilder.core; singleton:=true&#xA;Bundle-Version: 9.0.0.202009010132
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.commands' version='3.9.700.v20191217-1850' singleton='false' generation='2'>
      <update id='org.eclipse.core.commands' range='[0.0.0,3.9.700.v20191217-1850)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Commands'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.commands'/>
        <property name='maven-version' value='3.9.700-SNAPSHOT'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' version='3.9.700.v20191217-1850'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.commands' version='3.9.700.v20191217-1850'/>
        <provided namespace='java.package' name='org.eclipse.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.commands' version='3.9.700.v20191217-1850'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.commands' version='3.9.700.v20191217-1850'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.commands&#xA;Bundle-Version: 3.9.700.v20191217-1850
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.7.800.v20200724-0804' generation='2'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.7.800.v20200724-0804)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.contenttype'/>
        <property name='maven-version' value='3.7.800-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.7.800.v20200724-0804'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.7.800.v20200724-0804'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.contenttype' version='3.7.800.v20200724-0804'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.7.800.v20200724-0804'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.7.800.v20200724-0804
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding' version='1.10.0.v20200815-1752' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding' range='[0.0.0,1.10.0.v20200815-1752)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='JFace Data Binding'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding'/>
        <property name='maven-version' value='1.10.0-SNAPSHOT'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' version='1.10.0.v20200815-1752'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding' version='1.10.0.v20200815-1752'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.conversion.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.validation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.validation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding' version='1.10.0.v20200815-1752'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.core.databinding
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding' version='1.10.0.v20200815-1752'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding&#xA;Bundle-Version: 1.10.0.v20200815-1752
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.observable' version='1.10.0.v20200730-0848' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding.observable' range='[0.0.0,1.10.0.v20200730-0848)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='JFace Data Binding Observables'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding.observable'/>
        <property name='maven-version' value='1.10.0-SNAPSHOT'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' version='1.10.0.v20200730-0848'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' version='1.10.0.v20200730-0848'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.sideeffect' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.value' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.identity' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable.sideeffect' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding.observable' version='1.10.0.v20200730-0848'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.core.databinding.observable
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.observable' version='1.10.0.v20200730-0848'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.observable&#xA;Bundle-Version: 1.10.0.v20200730-0848
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.property' version='1.8.100.v20200619-0651' singleton='false' generation='2'>
      <update id='org.eclipse.core.databinding.property' range='[0.0.0,1.8.100.v20200619-0651)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='JFace Data Binding Properties'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.core.databinding.property'/>
        <property name='maven-version' value='1.8.100-SNAPSHOT'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' version='1.8.100.v20200619-0651'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.property' version='1.8.100.v20200619-0651'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.value' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.value' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.databinding.property' version='1.8.100.v20200619-0651'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.property' version='1.8.100.v20200619-0651'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.property&#xA;Bundle-Version: 1.8.100.v20200619-0651
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.7.0.v20200720-1126' generation='2'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.7.0.v20200720-1126)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.expressions'/>
        <property name='maven-version' value='3.7.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.7.0.v20200720-1126'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.7.0.v20200720-1126'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.expressions' version='3.7.0.v20200720-1126'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.7.0.v20200720-1126'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.7.0.v20200720-1126
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filebuffers' version='3.6.1000.v20200409-1035' generation='2'>
      <update id='org.eclipse.core.filebuffers' range='[0.0.0,3.6.1000.v20200409-1035)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='File Buffers'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.text'/>
        <property name='maven-artifactId' value='org.eclipse.core.filebuffers'/>
        <property name='maven-version' value='3.6.1000-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' version='3.6.1000.v20200409-1035'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filebuffers' version='3.6.1000.v20200409-1035'/>
        <provided namespace='java.package' name='org.eclipse.core.filebuffers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filebuffers.manipulation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filebuffers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.filebuffers' version='3.6.1000.v20200409-1035'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filebuffers' version='3.6.1000.v20200409-1035'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filebuffers; singleton:=true&#xA;Bundle-Version: 3.6.1000.v20200409-1035
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem' version='1.7.700.v20200110-1734' generation='2'>
      <update id='org.eclipse.core.filesystem' range='[0.0.0,1.7.700.v20200110-1734)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Core File Systems'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.resources'/>
        <property name='maven-artifactId' value='org.eclipse.core.filesystem'/>
        <property name='maven-version' value='1.7.700-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' version='1.7.700.v20200110-1734'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem' version='1.7.700.v20200110-1734'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local.unix' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.filesystem' version='1.7.700.v20200110-1734'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem' version='1.7.700.v20200110-1734'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem; singleton:=true&#xA;Bundle-Version: 1.7.700.v20200110-1734
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem.linux.x86_64' version='1.2.300.v20180828-0158'>
      <update id='org.eclipse.core.filesystem.linux.x86_64' range='[0.0.0,1.2.300.v20180828-0158)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.fragmentName' value='Core File System for Linux'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.filesystem.linux.x86_64'/>
        <property name='maven-version' value='1.2.300-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' version='1.2.300.v20180828-0158'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem.linux.x86_64' version='1.2.300.v20180828-0158'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.filesystem.linux.x86_64' version='1.2.300.v20180828-0158'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.filesystem' version='1.2.300.v20180828-0158'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.7.200,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem.linux.x86_64' version='1.2.300.v20180828-0158'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem.linux.x86_64; singleton:=true&#xA;Bundle-Version: 1.2.300.v20180828-0158&#xA;Fragment-Host: org.eclipse.core.filesystem;bundle-version=&quot;[1.7.200,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.10.800.v20200421-0950' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.10.800.v20200421-0950)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.jobs'/>
        <property name='maven-version' value='3.10.800-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.10.800.v20200421-0950'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.10.800.v20200421-0950
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources' version='3.13.800.v20200706-2152' generation='2'>
      <update id='org.eclipse.core.resources' range='[0.0.0,3.13.800.v20200706-2152)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Core Resource Management'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.resources'/>
        <property name='maven-artifactId' value='org.eclipse.core.resources'/>
        <property name='maven-version' value='3.13.800-SNAPSHOT'/>
      </properties>
      <provides size='23'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' version='3.13.800.v20200706-2152'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources' version='3.13.800.v20200706-2152'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.dtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.localstore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.projectvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.refresh.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.watson' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.filtermatchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.team' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.variableresolvers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.resources' version='3.13.800.v20200706-2152'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='[3.1.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.12.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources' version='3.13.800.v20200706-2152'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources; singleton:=true&#xA;Bundle-Version: 3.13.800.v20200706-2152
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.19.0.v20200724-1004' generation='2'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.19.0.v20200724-1004)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.runtime'/>
        <property name='maven-version' value='3.19.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.19.0.v20200724-1004'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.19.0.v20200724-1004'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.6.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.runtime' version='3.19.0.v20200724-1004'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.13.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.10.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.core.runtime
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.19.0.v20200724-1004'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.19.0.v20200724-1004
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.variables' version='3.4.800.v20200120-1101' generation='2'>
      <update id='org.eclipse.core.variables' range='[0.0.0,3.4.800.v20200120-1101)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Core Variables'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.variables'/>
        <property name='maven-version' value='3.4.800-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' version='3.4.800.v20200120-1101'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.variables' version='3.4.800.v20200120-1101'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.variables' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.variables' version='3.4.800.v20200120-1101'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.variables' version='3.4.800.v20200120-1101'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.variables; singleton:=true&#xA;Bundle-Version: 3.4.800.v20200120-1101
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.commands' version='0.12.900.v20200110-1732' generation='2'>
      <update id='org.eclipse.e4.core.commands' range='[0.0.0,0.12.900.v20200110-1732)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse e4 core commands'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.commands'/>
        <property name='maven-version' value='0.12.900-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.commands' version='0.12.900.v20200110-1732'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.commands' version='0.12.900.v20200110-1732'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.commands.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.commands' version='0.12.900.v20200110-1732'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.9.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.commands.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.expressions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.contexts' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.services.log' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.commands' version='0.12.900.v20200110-1732'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.commands;singleton:=true&#xA;Bundle-Version: 0.12.900.v20200110-1732
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.contexts' version='1.8.400.v20191217-1710' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.contexts' range='[0.0.0,1.8.400.v20191217-1710)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Contexts'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.e4'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.contexts'/>
        <property name='maven-version' value='1.8.400-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.contexts' version='1.8.400.v20191217-1710'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' version='1.8.400.v20191217-1710'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.contexts' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.contexts.osgi' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.contexts' version='1.8.400.v20191217-1710'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.contexts' version='1.8.400.v20191217-1710'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.contexts&#xA;Bundle-Version: 1.8.400.v20191217-1710
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di' version='1.7.600.v20200428-0912' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.di' range='[0.0.0,1.7.600.v20200428-0912)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Dependency Injection'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.e4'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di'/>
        <property name='maven-version' value='1.7.600-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di' version='1.7.600.v20200428-0912'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di' version='1.7.600.v20200428-0912'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.suppliers' version='1.7.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.di' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.di.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.di.shared' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di' version='1.7.600.v20200428-0912'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.annotations' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.1'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di' version='1.7.600.v20200428-0912'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di&#xA;Bundle-Version: 1.7.600.v20200428-0912
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di.annotations' version='1.6.600.v20191216-2352' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.di.annotations' range='[0.0.0,1.6.600.v20191216-2352)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.Bundle-Name' value='Eclipse Dependency Injection Annotations'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.e4'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di.annotations'/>
        <property name='maven-version' value='1.6.600-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.annotations' version='1.6.600.v20191216-2352'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di.annotations' version='1.6.600.v20191216-2352'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.annotations' version='1.6.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di.annotations' version='1.6.600.v20191216-2352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di.annotations' version='1.6.600.v20191216-2352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di.annotations&#xA;Bundle-Version: 1.6.600.v20191216-2352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di.extensions' version='0.16.0.v20200507-0938' generation='2'>
      <update id='org.eclipse.e4.core.di.extensions' range='[0.0.0,0.16.0.v20200507-0938)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Dependency Injection Extensions'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.e4'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di.extensions'/>
        <property name='maven-version' value='0.16.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions' version='0.16.0.v20200507-0938'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' version='0.16.0.v20200507-0938'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.extensions' version='0.16.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di.extensions' version='0.16.0.v20200507-0938'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.8.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di.extensions' version='0.16.0.v20200507-0938'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di.extensions;singleton:=true&#xA;Bundle-Version: 0.16.0.v20200507-0938
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.di.extensions.supplier' version='0.15.700.v20200622-1247' singleton='false' generation='2'>
      <update id='org.eclipse.e4.core.di.extensions.supplier' range='[0.0.0,0.15.700.v20200622-1247)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.Bundle-Name' value='Eclipse Dependency Injection Extensions Supplier'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.e4'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.di.extensions.supplier'/>
        <property name='maven-version' value='0.15.700-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.di.extensions.supplier' version='0.15.700.v20200622-1247'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions.supplier' version='0.15.700.v20200622-1247'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.internal.extensions' version='0.15.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.di.internal.extensions.util' version='0.15.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.di.extensions.supplier' version='0.15.700.v20200622-1247'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.contexts' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.annotations' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.extensions' range='0.15.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.suppliers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.3)(!(version&gt;=2.0)))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.di.extensions.supplier' version='0.15.700.v20200622-1247'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.di.extensions.supplier&#xA;Bundle-Version: 0.15.700.v20200622-1247
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.core.services' version='2.2.400.v20200622-1247' generation='2'>
      <update id='org.eclipse.e4.core.services' range='[0.0.0,2.2.400.v20200622-1247)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Application Services'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.e4'/>
        <property name='maven-artifactId' value='org.eclipse.e4.core.services'/>
        <property name='maven-version' value='2.2.400-SNAPSHOT'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.core.services' version='2.2.400.v20200622-1247'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.core.services' version='2.2.400.v20200622-1247'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.internal.services.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.contributions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.log' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.statusreporter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.core.services.translation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.core.services' version='2.2.400.v20200622-1247'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.0.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.2'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.core.services' version='2.2.400.v20200622-1247'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.core.services;singleton:=true&#xA;Bundle-Version: 2.2.400.v20200622-1247
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.emf.xpath' version='0.2.800.v20200609-0849' singleton='false' generation='2'>
      <update id='org.eclipse.e4.emf.xpath' range='[0.0.0,0.2.800.v20200609-0849)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.Bundle-Name' value='Eclipse Model Xpath'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.emf.xpath'/>
        <property name='maven-version' value='0.2.800-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.emf.xpath' version='0.2.800.v20200609-0849'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.emf.xpath' version='0.2.800.v20200609-0849'/>
        <provided namespace='java.package' name='org.eclipse.e4.emf.internal.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.emf.internal.xpath.helper' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.emf.xpath' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.emf.xpath' version='0.2.800.v20200609-0849'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.apache.commons.jxpath' range='1.2.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.16.100'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.emf.xpath' version='0.2.800.v20200609-0849'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.emf.xpath&#xA;Bundle-Version: 0.2.800.v20200609-0849
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.bindings' version='0.12.900.v20200513-0930' generation='2'>
      <update id='org.eclipse.e4.ui.bindings' range='[0.0.0,0.12.900.v20200513-0930)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Bindings Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.bindings'/>
        <property name='maven-version' value='0.12.900-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.bindings' version='0.12.900.v20200513-0930'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' version='0.12.900.v20200513-0930'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.bindings.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.bindings.keys' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.bindings' version='0.12.900.v20200513-0930'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='1.0.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.commands.internal' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.services.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.bindings' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.bindings.keys' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.bindings.keys.formatting' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.dialogs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.window' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.bindings' version='0.12.900.v20200513-0930'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.bindings;singleton:=true&#xA;Bundle-Version: 0.12.900.v20200513-0930
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.css.core' version='0.12.1300.v20200615-1701' generation='2'>
      <update id='org.eclipse.e4.ui.css.core' range='[0.0.0,0.12.1300.v20200615-1701)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse CSS Core Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.css.core'/>
        <property name='maven-version' value='0.12.1300-SNAPSHOT'/>
      </properties>
      <provides size='26'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.core' version='0.12.1300.v20200615-1701'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' version='0.12.1300.v20200615-1701'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.css2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties.converters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties.css2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.dom.properties.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.dom.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.dom.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.impl.sac' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.sac' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.serializers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.util.impl.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.util.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.core.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.css.core' version='0.12.1300.v20200615-1701'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.w3c.css.sac' range='1.3.0'/>
        <required namespace='osgi.bundle' name='org.apache.batik.css' range='[1.9.1,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.stylesheets' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.css.core' version='0.12.1300.v20200615-1701'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.css.core;singleton:=true&#xA;Bundle-Version: 0.12.1300.v20200615-1701
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.css.swt' version='0.13.1100.v20200819-0632' generation='2'>
      <update id='org.eclipse.e4.ui.css.swt' range='[0.0.0,0.13.1100.v20200819-0632)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse CSS SWT Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.css.swt'/>
        <property name='maven-version' value='0.13.1100-SNAPSHOT'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt' version='0.13.1100.v20200819-0632'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' version='0.13.1100.v20200819-0632'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom.definition' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.dom.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.converters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.css2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.definition' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.properties.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.serializers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.css.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.css.swt.definition' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.css.swt' version='0.13.1100.v20200819-0632'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.12.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.106.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.w3c.css.sac' range='1.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.jface.resource' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.e4.ui.css.swt
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.css.swt' version='0.13.1100.v20200819-0632'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.css.swt;singleton:=true&#xA;Bundle-Version: 0.13.1100.v20200819-0632
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.css.swt.theme' version='0.12.700.v20200527-0719' generation='2'>
      <update id='org.eclipse.e4.ui.css.swt.theme' range='[0.0.0,0.12.700.v20200527-0719)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse CSS SWT Theme Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.css.swt.theme'/>
        <property name='maven-version' value='0.12.700-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.css.swt.theme' version='0.12.700.v20200527-0719'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' version='0.12.700.v20200527-0719'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.internal.theme' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.css.swt.theme' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.css.swt.theme' version='0.12.700.v20200527-0719'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.13.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.12.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.w3c.css.sac' range='1.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.8.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.css.swt.theme' version='0.12.700.v20200527-0719'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.css.swt.theme;singleton:=true&#xA;Bundle-Version: 0.12.700.v20200527-0719
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.di' version='1.2.800.v20200128-0855' singleton='false' generation='2'>
      <update id='org.eclipse.e4.ui.di' range='[0.0.0,1.2.800.v20200128-0855)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse UI Dependency Injection'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.di'/>
        <property name='maven-version' value='1.2.800-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.di' version='1.2.800.v20200128-0855'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.di' version='1.2.800.v20200128-0855'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.di' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.di' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.di' version='1.2.800.v20200128-0855'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.contexts' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.annotations' range='0.15.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.internal.extensions' range='0.15.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.di.suppliers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.di' version='1.2.800.v20200128-0855'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.di&#xA;Bundle-Version: 1.2.800.v20200128-0855
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.dialogs' version='1.2.0.v20200807-0944' singleton='false' generation='2'>
      <update id='org.eclipse.e4.ui.dialogs' range='[0.0.0,1.2.0.v20200807-0944)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse e4 dialogs'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.dialogs'/>
        <property name='maven-version' value='1.2.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.dialogs' version='1.2.0.v20200807-0944'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.dialogs' version='1.2.0.v20200807-0944'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.dialogs.filteredtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.dialogs.textbundles' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.dialogs.about' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.dialogs' version='1.2.0.v20200807-0944'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.18.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.e4.ui.dialogs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.dialogs' version='1.2.0.v20200807-0944'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.dialogs&#xA;Bundle-Version: 1.2.0.v20200807-0944
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.model.workbench' version='2.1.800.v20200828-0938' generation='2'>
      <update id='org.eclipse.e4.ui.model.workbench' range='[0.0.0,2.1.800.v20200828-0938)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Workbench Model'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.model.workbench'/>
        <property name='maven-version' value='2.1.800-SNAPSHOT'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.model.workbench' version='2.1.800.v20200828-0938'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' version='2.1.800.v20200828-0938'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.commands.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.descriptor.basic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.descriptor.basic.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.descriptor.basic.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.advanced' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.advanced.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.advanced.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.basic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.basic.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.basic.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.menu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.menu.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.menu.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.ui.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.application.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.fragment' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.fragment.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.fragment.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.model.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.model.workbench' version='2.1.800.v20200828-0938'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.emf.xpath' range='0.1.100'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.e4.ui.model.workbench
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.model.workbench' version='2.1.800.v20200828-0938'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.model.workbench;singleton:=true&#xA;Bundle-Version: 2.1.800.v20200828-0938
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.services' version='1.3.700.v20190930-1643' generation='2'>
      <update id='org.eclipse.e4.ui.services' range='[0.0.0,1.3.700.v20190930-1643)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse UI Application Services'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.services'/>
        <property name='maven-version' value='1.3.700-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.services' version='1.3.700.v20190930-1643'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.services' version='1.3.700.v20190930-1643'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.services.internal.events' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.services' version='1.3.700.v20190930-1643'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.1'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'/>
        <requiredProperties namespace='osgi.service' match='(objectClass=org.osgi.service.event.EventAdmin)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.services' version='1.3.700.v20190930-1643'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.services;singleton:=true&#xA;Bundle-Version: 1.3.700.v20190930-1643
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.widgets' version='1.2.700.v20191222-1048' singleton='false' generation='2'>
      <update id='org.eclipse.e4.ui.widgets' range='[0.0.0,1.2.700.v20191222-1048)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse UI Custom widgets'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.widgets'/>
        <property name='maven-version' value='1.2.700-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.widgets' version='1.2.700.v20191222-1048'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.widgets' version='1.2.700.v20191222-1048'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.widgets' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.widgets' version='1.2.700.v20191222-1048'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.widgets' version='1.2.700.v20191222-1048'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.widgets&#xA;Bundle-Version: 1.2.700.v20191222-1048
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench' version='1.11.400.v20200828-0938' generation='2'>
      <update id='org.eclipse.e4.ui.workbench' range='[0.0.0,1.11.400.v20200828-0938)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench'/>
        <property name='maven-version' value='1.11.400-SNAPSHOT'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench' version='1.11.400.v20200828-0938'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' version='1.11.400.v20200828-0938'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.addons' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.lifecycle' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.modeling' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench' version='1.11.400.v20200828-0938'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='1.2.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.11.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.change' range='2.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.annotation' range='2.2.200' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.emf.xpath' range='0.2.500'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.apache.commons.jxpath' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.e4.ui.workbench
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.service' match='(objectClass=org.osgi.service.event.EventAdmin)'>
          <description>
            org.eclipse.e4.ui.workbench
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.e4.ui.workbench
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench' version='1.11.400.v20200828-0938'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench;singleton:=true&#xA;Bundle-Version: 1.11.400.v20200828-0938
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench.addons.swt' version='1.3.1100.v20200703-0611' generation='2'>
      <update id='org.eclipse.e4.ui.workbench.addons.swt' range='[0.0.0,1.3.1100.v20200703-0611)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench Add-ons'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench.addons.swt'/>
        <property name='maven-version' value='1.3.1100-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.addons.swt' version='1.3.1100.v20200703-0611'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.addons.swt' version='1.3.1100.v20200703-0611'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.cleanupaddon' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.dndaddon' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.minmax' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.splitteraddon' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.swt' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench.addons.swt' version='1.3.1100.v20200703-0611'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='1.5.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.renderers.swt' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.widgets' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.7.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench.addons.swt' version='1.3.1100.v20200703-0611'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench.addons.swt;singleton:=true&#xA;Bundle-Version: 1.3.1100.v20200703-0611
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench.renderers.swt' version='0.14.1300.v20200829-1411' generation='2'>
      <update id='org.eclipse.e4.ui.workbench.renderers.swt' range='[0.0.0,0.14.1300.v20200829-1411)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench SWT Renderer'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench.renderers.swt'/>
        <property name='maven-version' value='0.14.1300-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.14.1300.v20200829-1411'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.14.1300.v20200829-1411'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.renderers.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench.renderers.swt' version='0.14.1300.v20200829-1411'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.15.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.12.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.5.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.17.100'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.e4.ui.workbench.renderers.swt
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench.renderers.swt' version='0.14.1300.v20200829-1411'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench.renderers.swt;singleton:=true&#xA;Bundle-Version: 0.14.1300.v20200829-1411
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench.swt' version='0.14.1100.v20200619-0644' generation='2'>
      <update id='org.eclipse.e4.ui.workbench.swt' range='[0.0.0,0.14.1100.v20200619-0644)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse e4 Workbench SWT'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench.swt'/>
        <property name='maven-version' value='0.14.1100-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench.swt' version='0.14.1100.v20200619-0644'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' version='0.14.1100.v20200619-0644'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt.factories' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt.internal.copy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.swt.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench.swt' version='0.14.1100.v20200619-0644'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='35'>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench' range='0.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='0.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.dialogs' range='1.1.600'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.databinding' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.12.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.13.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench3' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' range='0.12.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.commands' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.widgets' range='0.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.urischeme' range='1.1.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench.swt' version='0.14.1100.v20200619-0644'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench.swt;singleton:=true&#xA;Bundle-Version: 0.14.1100.v20200619-0644
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.e4.ui.workbench3' version='0.15.400.v20191216-0805' generation='2'>
      <update id='org.eclipse.e4.ui.workbench3' range='[0.0.0,0.15.400.v20191216-0805)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Bundle for Workbench APIs available in e4'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.e4.ui.workbench3'/>
        <property name='maven-version' value='0.15.400-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.e4.ui.workbench3' version='0.15.400.v20191216-0805'/>
        <provided namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench3' version='0.15.400.v20191216-0805'/>
        <provided namespace='java.package' name='org.eclipse.ui.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.testing.dumps' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.e4.ui.workbench3' version='0.15.400.v20191216-0805'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.15.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.e4.ui.workbench3' version='0.15.400.v20191216-0805'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.e4.ui.workbench3;singleton:=true&#xA;Bundle-Version: 0.15.400.v20191216-0805
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.common' version='2.20.0.v20200822-0801' generation='2'>
      <update id='org.eclipse.emf.common' range='[0.0.0,2.20.0.v20200822-0801)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='EMF Common'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.common'/>
        <property name='maven-version' value='2.20.0-SNAPSHOT'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' version='2.20.0.v20200822-0801'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.common' version='2.20.0.v20200822-0801'/>
        <provided namespace='java.package' name='org.eclipse.emf.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.archive' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.command' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.common' version='2.20.0.v20200822-0801'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.common' version='2.20.0.v20200822-0801'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.common;singleton:=true&#xA;Bundle-Version: 2.20.0.v20200822-0801
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore' version='2.23.0.v20200630-0516' generation='2'>
      <update id='org.eclipse.emf.ecore' range='[0.0.0,2.23.0.v20200630-0516)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='EMF Ecore'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore'/>
        <property name='maven-version' value='2.23.0-SNAPSHOT'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' version='2.23.0.v20200630-0516'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore' version='2.23.0.v20200630-0516'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore' version='2.23.0.v20200630-0516'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='[2.20.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.6.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.datatype' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore' version='2.23.0.v20200630-0516'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore;singleton:=true&#xA;Bundle-Version: 2.23.0.v20200630-0516
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.change' version='2.14.0.v20190528-0725' generation='2'>
      <update id='org.eclipse.emf.ecore.change' range='[0.0.0,2.14.0.v20190528-0725)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='EMF Change Model'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.change'/>
        <property name='maven-version' value='2.14.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change' version='2.14.0.v20190528-0725'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.change' version='2.14.0.v20190528-0725'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.change' version='2.14.0.v20190528-0725'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.18.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.change' version='2.14.0.v20190528-0725'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.change;singleton:=true&#xA;Bundle-Version: 2.14.0.v20190528-0725
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.xmi' version='2.16.0.v20190528-0725' generation='2'>
      <update id='org.eclipse.emf.ecore.xmi' range='[0.0.0,2.16.0.v20190528-0725)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='EMF XML/XMI Persistence'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.xmi'/>
        <property name='maven-version' value='2.16.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi' version='2.16.0.v20190528-0725'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' version='2.16.0.v20190528-0725'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.xmi' version='2.16.0.v20190528-0725'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.18.0,3.0.0)'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.xmi' version='2.16.0.v20190528-0725'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.xmi; singleton:=true&#xA;Bundle-Version: 2.16.0.v20190528-0725
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.5.0.v20200717-0620' generation='2'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.5.0.v20200717-0620)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.app'/>
        <property name='maven-version' value='1.5.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.5.0.v20200717-0620'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.5.0.v20200717-0620'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.app' version='1.5.0.v20200717-0620'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.5.0.v20200717-0620'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.5.0.v20200717-0620
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.bidi' version='1.3.0.v20200612-1624' generation='2'>
      <update id='org.eclipse.equinox.bidi' range='[0.0.0,1.3.0.v20200612-1624)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Bidirectional Text Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.bidi'/>
        <property name='maven-version' value='1.3.0-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.bidi' version='1.3.0.v20200612-1624'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.bidi' version='1.3.0.v20200612-1624'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.advanced' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.bidi.internal.consumable' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.bidi' version='1.3.0.v20200612-1624'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.bidi' version='1.3.0.v20200612-1624'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.bidi;singleton:=true&#xA;Bundle-Version: 1.3.0.v20200612-1624
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.13.0.v20200828-1034' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.13.0.v20200828-1034)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.common'/>
        <property name='maven-version' value='3.13.0-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.13.0.v20200828-1034'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.13.0.v20200828-1034'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.6.0'/>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.13.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.13.0.v20200828-1034'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='java.package' name='org.eclipse.equinox.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.urlconversion' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.13.0.v20200828-1034'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.13.0.v20200828-1034
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.event' version='1.5.500.v20200616-0800' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.event' range='[0.0.0,1.5.500.v20200616-0800)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Event Admin'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.event'/>
        <property name='maven-version' value='1.5.500-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' version='1.5.500.v20200616-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.event' version='1.5.500.v20200616-0800'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event.mapper' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.event' version='1.5.500.v20200616-0800'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.equinox.event_1.5.500.v20200616-0800-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.event.EventAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.implementation' name='osgi.event' version='1.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.event' version='1.5.500.v20200616-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.event&#xA;Bundle-Version: 1.5.500.v20200616-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.5.800.v20200727-1323' generation='2'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.5.800.v20200727-1323)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher'/>
        <property name='maven-version' value='1.5.800-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.5.800.v20200727-1323'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.5.800.v20200727-1323'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher' version='1.5.800.v20200727-1323'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.eclipse.equinox.launcher
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.5.800.v20200727-1323'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.5.800.v20200727-1323
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940'>
      <update id='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[0.0.0,1.1.1300.v20200819-0940)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Launcher Linux X86_64 Fragment'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.gtk.linux.x86_64'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher.gtk.linux.x86_64'/>
        <property name='maven-version' value='1.1.1300-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.1.1300.v20200819-0940'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.0.0,1.6.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.gtk.linux.x86_64;singleton:=true&#xA;Bundle-Version: 1.1.1300.v20200819-0940&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.0.0,1.6.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.8.0.v20200422-1833)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.preferences'/>
        <property name='maven-version' value='3.8.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.1,1.2.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.8.0.v20200422-1833'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.8.0.v20200422-1833
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.9.0.v20200625-1425' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.9.0.v20200625-1425)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.registry'/>
        <property name='maven-version' value='3.9.0-SNAPSHOT'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.9.0.v20200625-1425'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.9.0.v20200625-1425'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.6.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.9.0.v20200625-1425'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.9.0.v20200625-1425'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.9.0.v20200625-1425
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help' version='3.8.800.v20200525-0755' generation='2'>
      <update id='org.eclipse.help' range='[0.0.0,3.8.800.v20200525-0755)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.help_plugin_name' value='Help System Core'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.help'/>
        <property name='maven-artifactId' value='org.eclipse.help'/>
        <property name='maven-version' value='3.8.800-SNAPSHOT'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' version='3.8.800.v20200525-0755'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help' version='3.8.800.v20200525-0755'/>
        <provided namespace='java.package' name='org.eclipse.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.context' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.criteria' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.entityresolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.toc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.help' version='3.8.800.v20200525-0755'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help' version='3.8.800.v20200525-0755'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help; singleton:=true&#xA;Bundle-Version: 3.8.800.v20200525-0755
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt.annotation' version='2.2.600.v20200408-1511' singleton='false' generation='2'>
      <update id='org.eclipse.jdt.annotation' range='[0.0.0,2.2.600.v20200408-1511)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='JDT Annotations for Enhanced Null Analysis'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='bundle'/>
        <property name='maven-groupId' value='org.eclipse.jdt'/>
        <property name='maven-artifactId' value='org.eclipse.jdt.annotation'/>
        <property name='maven-version' value='2.2.600-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.annotation' version='2.2.600.v20200408-1511'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jdt.annotation' version='2.2.600.v20200408-1511'/>
        <provided namespace='java.package' name='org.eclipse.jdt.annotation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jdt.annotation' version='2.2.600.v20200408-1511'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jdt.annotation' version='2.2.600.v20200408-1511'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jdt.annotation&#xA;Bundle-Version: 2.2.600.v20200408-1511
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface' version='3.21.0.v20200821-1458' generation='2'>
      <update id='org.eclipse.jface' range='[0.0.0,3.21.0.v20200821-1458)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='JFace'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.jface'/>
        <property name='maven-artifactId' value='org.eclipse.jface'/>
        <property name='maven-version' value='3.21.0-SNAPSHOT'/>
      </properties>
      <provides size='33'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' version='3.21.0.v20200821-1458'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface' version='3.21.0.v20200821-1458'/>
        <provided namespace='java.package' name='org.eclipse.jface' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys.formatting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.provisional.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.operation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers.deferred' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.window' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard.images' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jface' version='3.21.0.v20200821-1458'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.111.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.bidi' range='[0.10.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.jface
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface' version='3.21.0.v20200821-1458'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface;singleton:=true&#xA;Bundle-Version: 3.21.0.v20200821-1458
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.databinding' version='1.12.0.v20200717-1533' singleton='false' generation='2'>
      <update id='org.eclipse.jface.databinding' range='[0.0.0,1.12.0.v20200717-1533)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='JFace Data Binding for SWT and JFace'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.jface'/>
        <property name='maven-artifactId' value='org.eclipse.jface.databinding'/>
        <property name='maven-version' value='1.12.0-SNAPSHOT'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' version='1.12.0.v20200717-1533'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.databinding' version='1.12.0.v20200717-1533'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.dialog' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.swt.typed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.viewers.typed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.viewers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jface.databinding' version='1.12.0.v20200717-1533'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.databinding' version='1.12.0.v20200717-1533'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.databinding&#xA;Bundle-Version: 1.12.0.v20200717-1533
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.notifications' version='0.2.0.v20200810-0826' singleton='false' generation='2'>
      <update id='org.eclipse.jface.notifications' range='[0.0.0,0.2.0.v20200810-0826)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Notification API'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.jface.notifications'/>
        <property name='maven-version' value='0.2.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.notifications' version='0.2.0.v20200810-0826'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.notifications' version='0.2.0.v20200810-0826'/>
        <provided namespace='java.package' name='org.eclipse.jface.notifications' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.notifications.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jface.notifications' version='0.2.0.v20200810-0826'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.18.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.20.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.jface.notifications
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.notifications' version='0.2.0.v20200810-0826'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.notifications&#xA;Bundle-Version: 0.2.0.v20200810-0826
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ltk.core.refactoring' version='3.11.100.v20200720-0748' generation='2'>
      <update id='org.eclipse.ltk.core.refactoring' range='[0.0.0,3.11.100.v20200720-0748)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Refactoring Core'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ltk'/>
        <property name='maven-artifactId' value='org.eclipse.ltk.core.refactoring'/>
        <property name='maven-version' value='3.11.100-SNAPSHOT'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' version='3.11.100.v20200720-0748'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' version='3.11.100.v20200720-0748'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.participants' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.resource.undostates' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ltk.core.refactoring' version='3.11.100.v20200720-0748'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.11.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ltk.core.refactoring' version='3.11.100.v20200720-0748'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ltk.core.refactoring; singleton:=true&#xA;Bundle-Version: 3.11.100.v20200720-0748
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.16.0.v20200828-0759' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.16.0.v20200828-0759)' severity='0'/>
      <properties size='10'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi'/>
        <property name='maven-version' value='3.16.0-SNAPSHOT'/>
      </properties>
      <provides size='94'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.16.0.v20200828-0759'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.16.0.v20200828-0759'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.5.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.10.0'/>
        <provided namespace='java.package' name='org.osgi.framework.connect' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condition' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.2'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.16.0.v20200828-0759'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.16.0.v20200828-0759-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(version=1.8)(|(osgi.ee=JavaSE)(osgi.ee=JavaSE/compact1)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.16.0.v20200828-0759'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.16.0.v20200828-0759
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.9.0.v20200511-1725' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.9.0.v20200511-1725)' severity='0'/>
      <properties size='12'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.services'/>
        <property name='maven-version' value='3.9.0-SNAPSHOT'/>
      </properties>
      <provides size='23'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.9.0.v20200511-1725'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.9.0.v20200511-1725'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.6.0'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.context' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime.dto' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.services' version='3.9.0.v20200511-1725'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='java.package' name='org.osgi.service.http.whiteboard' range='[1.1.0,1.2.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,1.7.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.context' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime.dto' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.9.0.v20200511-1725'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.9.0.v20200511-1725
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.5.300.v20190708-1141' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.5.300.v20190708-1141)' severity='0'/>
      <properties size='12'>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.util'/>
        <property name='maven-version' value='3.5.300-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.2'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='org.osgi.framework' range='1.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.2,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.position' range='[1.0.1,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.1.1,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.xml' range='[1.0.1,1.1.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.5.300.v20190708-1141'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.5.300.v20190708-1141
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt' version='3.115.0.v20200831-1002' generation='2'>
      <update id='org.eclipse.swt' range='[0.0.0,3.115.0.v20200831-1002)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Standard Widget Toolkit'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.swt'/>
        <property name='maven-artifactId' value='org.eclipse.swt'/>
        <property name='maven-version' value='3.115.0-SNAPSHOT'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' version='3.115.0.v20200831-1002'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt' version='3.115.0.v20200831-1002'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.swt' version='3.115.0.v20200831-1002'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.aarch64' range='[3.115.0.v20200831-1002,3.115.0.v20200831-1002]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.swt
          </description>
        </requiredProperties>
        <required namespace='java.package' name='org.eclipse.swt.accessibility2' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.ppc64le' range='[3.115.0.v20200831-1002,3.115.0.v20200831-1002]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='[3.115.0.v20200831-1002,3.115.0.v20200831-1002]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='[3.115.0.v20200831-1002,3.115.0.v20200831-1002]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='[3.115.0.v20200831-1002,3.115.0.v20200831-1002]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32)(!(org.eclipse.swt.buildtime=true)))
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt' version='3.115.0.v20200831-1002'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt; singleton:=true&#xA;Bundle-Version: 3.115.0.v20200831-1002
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt.gtk.linux.x86_64' version='3.115.0.v20200831-1002'>
      <update id='org.eclipse.swt.gtk.linux.x86_64' range='[0.0.0,3.115.0.v20200831-1002)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.fragmentName' value='Standard Widget Toolkit for GTK'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.swt'/>
        <property name='maven-artifactId' value='org.eclipse.swt.gtk.linux.x86_64'/>
        <property name='maven-version' value='3.115.0-SNAPSHOT'/>
      </properties>
      <provides size='25'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' version='3.115.0.v20200831-1002'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt.gtk.linux.x86_64' version='3.115.0.v20200831-1002'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.accessibility.gtk' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.cairo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gtk' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.opengl.glx' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.swt.gtk.linux.x86_64' version='3.115.0.v20200831-1002'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.swt' version='3.115.0.v20200831-1002'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.0.0,4.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt.gtk.linux.x86_64' version='3.115.0.v20200831-1002'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt.gtk.linux.x86_64; singleton:=true&#xA;Bundle-Version: 3.115.0.v20200831-1002&#xA;Fragment-Host: org.eclipse.swt; bundle-version=&quot;[3.0.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.text' version='3.10.300.v20200807-0831' singleton='false' generation='2'>
      <update id='org.eclipse.text' range='[0.0.0,3.10.300.v20200807-0831)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Text'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.text'/>
        <property name='maven-artifactId' value='org.eclipse.text'/>
        <property name='maven-version' value='3.10.300-SNAPSHOT'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' version='3.10.300.v20200807-0831'/>
        <provided namespace='osgi.bundle' name='org.eclipse.text' version='3.10.300.v20200807-0831'/>
        <provided namespace='java.package' name='org.eclipse.jface.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.projection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.edits' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.undo' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.text' version='3.10.300.v20200807-0831'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.14.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.text
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.text' version='3.10.300.v20200807-0831'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.text&#xA;Bundle-Version: 3.10.300.v20200807-0831
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.tools.templates.core' version='1.2.0.202008310315' singleton='false' generation='2'>
      <update id='org.eclipse.tools.templates.core' range='[0.0.0,1.2.0.202008310315)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Template Engine Core'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.tools.templates.core'/>
        <property name='maven-version' value='1.2.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.templates.core' version='1.2.0.202008310315'/>
        <provided namespace='osgi.bundle' name='org.eclipse.tools.templates.core' version='1.2.0.202008310315'/>
        <provided namespace='java.package' name='org.eclipse.tools.templates.core' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.tools.templates.core' version='1.2.0.202008310315'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.tools.templates.core' version='1.2.0.202008310315'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.tools.templates.core&#xA;Bundle-Version: 1.2.0.202008310315
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.tools.templates.freemarker' version='1.2.0.202008311307' singleton='false' generation='2'>
      <update id='org.eclipse.tools.templates.freemarker' range='[0.0.0,1.2.0.202008311307)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Template Engine Freemarker Support'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.tools.templates.freemarker'/>
        <property name='maven-version' value='1.2.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tools.templates.freemarker' version='1.2.0.202008311307'/>
        <provided namespace='osgi.bundle' name='org.eclipse.tools.templates.freemarker' version='1.2.0.202008311307'/>
        <provided namespace='java.package' name='org.eclipse.tools.templates.freemarker' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.tools.templates.freemarker' version='1.2.0.202008311307'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.freemarker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.tools.templates.core' range='1.1.2'/>
        <required namespace='osgi.bundle' name='com.sun.xml.bind' range='2.2.0'/>
        <required namespace='java.package' name='javax.xml.bind' range='2.2.0'/>
        <required namespace='java.package' name='javax.xml.bind.annotation' range='2.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.tools.templates.freemarker' version='1.2.0.202008311307'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.tools.templates.freemarker&#xA;Bundle-Version: 1.2.0.202008311307
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui' version='3.118.0.v20200807-0902' generation='2'>
      <update id='org.eclipse.ui' range='[0.0.0,3.118.0.v20200807-0902)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Eclipse UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.ui'/>
        <property name='maven-version' value='3.118.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' version='3.118.0.v20200807-0902'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui' version='3.118.0.v20200807-0902'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ui' version='3.118.0.v20200807-0902'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.103.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.19.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.120.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.ui
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui' version='3.118.0.v20200807-0902'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui; singleton:=true&#xA;Bundle-Version: 3.118.0.v20200807-0902
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.workbench' version='3.120.0.v20200829-1411' generation='2'>
      <update id='org.eclipse.ui.workbench' range='[0.0.0,3.120.0.v20200829-1411)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Workbench'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ui'/>
        <property name='maven-artifactId' value='org.eclipse.ui.workbench'/>
        <property name='maven-version' value='3.120.0-SNAPSHOT'/>
      </properties>
      <provides size='81'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' version='3.120.0.v20200829-1411'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.workbench' version='3.120.0.v20200829-1411'/>
        <provided namespace='java.package' name='org.eclipse.e4.ui.workbench.addons.perspectiveswitcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.activities' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.branding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.databinding.typed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.activities' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.activities.ws' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.decorators' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.dialogs.cpd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.e4.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.e4.migration' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editorsupport' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.keys.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.progress' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.provisional.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.quickaccess' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.quickaccess.providers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.statushandlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.themes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.tweaklets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.intro' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.progress' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.quickaccess' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.statushandlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.themes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.ui.workbench' version='3.120.0.v20200829-1411'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='47'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.19.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.107.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.databinding' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.services' range='2.2.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.contexts' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di' range='1.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.swt' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.di' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.model.workbench' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt.theme' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.bindings' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.swt' range='0.9.1'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.css.core' range='0.9.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench3' range='0.15.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.workbench.addons.swt' range='0.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.ui.services' range='1.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.11.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.e4.core.di.extensions' range='0.13.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
        <required namespace='java.package' name='javax.annotation' range='0.0.0'/>
        <required namespace='java.package' name='javax.inject' range='1.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.commands' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.core.commands.internal' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.internal.workbench' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.addons' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.renderers.swt' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.internal.workbench.swt' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.services' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.workbench' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.workbench.modeling' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.e4.ui.workbench.renderers.swt' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.emf.common.util' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.jface.notifications' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.2.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.css' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.ui.workbench
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.ui.workbench
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.workbench' version='3.120.0.v20200829-1411'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.workbench; singleton:=true&#xA;Bundle-Version: 3.120.0.v20200829-1411
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.urischeme' version='1.1.100.v20200729-2048' generation='2'>
      <update id='org.eclipse.urischeme' range='[0.0.0,1.1.100.v20200729-2048)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Plugin.name' value='Eclipse URI Scheme Handling'/>
        <property name='df_LT.Plugin.Providername' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.Providername'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='eclipse.platform.ui'/>
        <property name='maven-artifactId' value='org.eclipse.urischeme'/>
        <property name='maven-version' value='1.1.100-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.urischeme' version='1.1.100.v20200729-2048'/>
        <provided namespace='osgi.bundle' name='org.eclipse.urischeme' version='1.1.100.v20200729-2048'/>
        <provided namespace='java.package' name='org.eclipse.urischeme' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.urischeme' version='1.1.100.v20200729-2048'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.14.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='com.sun.jna' range='[4.5.1,6.0.0)'/>
        <required namespace='osgi.bundle' name='com.sun.jna.platform' range='[4.5.1,6.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.urischeme
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.urischeme' version='1.1.100.v20200729-2048'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.urischeme;singleton:=true&#xA;Bundle-Version: 1.1.100.v20200729-2048
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.freemarker' version='2.3.22.v20160210-1233' singleton='false'>
      <update id='org.freemarker' range='[0.0.0,2.3.22.v20160210-1233)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='FreeMarker'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.freemarker'/>
        <property name='maven-version' value='2.3.22-SNAPSHOT'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.freemarker' version='2.3.22.v20160210-1233'/>
        <provided namespace='osgi.bundle' name='org.freemarker' version='2.3.22.v20160210-1233'/>
        <provided namespace='java.package' name='freemarker.debug.impl' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.cache' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.core' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.debug' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.ant' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.beans' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.dom' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.jdom' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.jsp' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.jython' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.rhino' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.servlet' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.util' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.ext.xml' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.log' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.template' version='2.3.22'/>
        <provided namespace='java.package' name='freemarker.template.utility' version='2.3.22'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='54'>
        <required namespace='java.package' name='com.sun.org.apache.xml.internal.utils' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.org.apache.xpath.internal' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.org.apache.xpath.internal.objects' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.cache' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.core' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.debug' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.debug.impl' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.beans' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.dom' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.jsp' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.jython' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.servlet' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.util' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.ext.xml' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.log' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.template' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='freemarker.template.utility' range='[2.3.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.el' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.jsp.el' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.jsp.tagext' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.swing' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.swing.tree' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.tools.ant' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.tools.ant.taskdefs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xml.utils' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xpath' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.xpath.objects' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.dom4j' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.dom4j.tree' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jaxen' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jaxen.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jaxen.dom4j' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jaxen.jdom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jdom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jdom.input' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.jdom.output' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.mozilla.javascript' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.python.core' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.python.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.slf4j' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.slf4j.spi' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom.traversal' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.zeroturnaround.javarebel' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.freemarker' version='2.3.22.v20160210-1233'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.freemarker&#xA;Bundle-Version: 2.3.22.v20160210-1233
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.jdom' version='1.1.1.v201101151400' singleton='false'>
      <update id='org.jdom' range='[0.0.0,1.1.1.v201101151400)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Vendor.0' value='Eclipse Orbit'/>
        <property name='df_LT.Bundle-Name.0' value='JDOM'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor.0'/>
        <property name='iplog.bug_id' value='4788'/>
        <property name='iplog.contact.name' value='Chris Aniszczyk'/>
        <property name='iplog.contact.email' value='caniszczyk@gmail.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.jdom' version='1.1.1.v201101151400'/>
        <provided namespace='osgi.bundle' name='org.jdom' version='1.1.1.v201101151400'/>
        <provided namespace='java.package' name='org.jdom' version='1.1.1'/>
        <provided namespace='java.package' name='org.jdom.adapters' version='1.1.1'/>
        <provided namespace='java.package' name='org.jdom.filter' version='1.1.1'/>
        <provided namespace='java.package' name='org.jdom.input' version='1.1.1'/>
        <provided namespace='java.package' name='org.jdom.output' version='1.1.1'/>
        <provided namespace='java.package' name='org.jdom.transform' version='1.1.1'/>
        <provided namespace='java.package' name='org.jdom.xpath' version='1.1.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.apache.xerces' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.jdom' version='1.1.1.v201101151400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.jdom&#xA;Bundle-Version: 1.1.1.v201101151400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.ojalgo' version='38.18.0' singleton='false' generation='2'>
      <update id='org.ojalgo' range='[0.0.0,38.18.0)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Library-ojAlgo'/>
        <property name='maven-groupId' value='org.ojalgo'/>
        <property name='maven-artifactId' value='org.ojalgo'/>
        <property name='maven-version' value='38.18.0'/>
      </properties>
      <provides size='40'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.ojalgo' version='38.18.0'/>
        <provided namespace='osgi.bundle' name='org.ojalgo' version='38.18.0'/>
        <provided namespace='java.package' name='org.ojalgo' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.access' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.algebra' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.array' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.constant' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.finance' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.finance.data' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.finance.portfolio' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.finance.portfolio.simulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.function' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.function.aggregator' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.function.multiary' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.function.polynomial' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.machine' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.matrix' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.matrix.decomposition' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.matrix.store' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.matrix.store.operation' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.matrix.task' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.matrix.transformation' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.netio' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.optimisation' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.optimisation.convex' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.optimisation.integer' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.optimisation.linear' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.random' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.random.process' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.scalar' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.series' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.series.function' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.series.primitive' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.type' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.type.context' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.type.format' version='0.0.0'/>
        <provided namespace='java.package' name='org.ojalgo.type.keyvalue' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.ojalgo' version='38.18.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.ojalgo' version='38.18.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.ojalgo&#xA;Bundle-Version: 38.18.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.w3c.css.sac' version='1.3.1.v200903091627' singleton='false'>
      <update id='org.w3c.css.sac' range='[0.0.0,1.3.1.v200903091627)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='W3C CSS SAC'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='2166'/>
        <property name='iplog.contact.name' value='Anthony Hunter'/>
        <property name='iplog.contact.email' value='anthonyh{at}ca.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.w3c.css.sac' version='1.3.1.v200903091627'/>
        <provided namespace='osgi.bundle' name='org.w3c.css.sac' version='1.3.1.v200903091627'/>
        <provided namespace='java.package' name='org.w3c.css.sac' version='1.3.0'/>
        <provided namespace='java.package' name='org.w3c.css.sac.helpers' version='1.3.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.w3c.css.sac' version='1.3.1.v200903091627'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.w3c.css.sac&#xA;Bundle-Version: 1.3.1.v200903091627
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.w3c.dom.events' version='3.0.0.draft20060413_v201105210656' singleton='false'>
      <update id='org.w3c.dom.events' range='[0.0.0,3.0.0.draft20060413_v201105210656)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='W3C DOM Level 3 Events'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='2940'/>
        <property name='iplog.contact.name' value='Anthony Hunter'/>
        <property name='iplog.contact.email' value='anthonyh{at}ca.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.w3c.dom.events' version='3.0.0.draft20060413_v201105210656'/>
        <provided namespace='osgi.bundle' name='org.w3c.dom.events' version='3.0.0.draft20060413_v201105210656'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='3.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.w3c.dom.events' version='3.0.0.draft20060413_v201105210656'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.w3c.dom.events&#xA;Bundle-Version: 3.0.0.draft20060413_v201105210656
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.w3c.dom.smil' version='1.0.1.v200903091627' singleton='false'>
      <update id='org.w3c.dom.smil' range='[0.0.0,1.0.1.v200903091627)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='W3C SMIL DOM'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='2166'/>
        <property name='iplog.contact.name' value='Anthony Hunter'/>
        <property name='iplog.contact.email' value='anthonyh{at}ca.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.w3c.dom.smil' version='1.0.1.v200903091627'/>
        <provided namespace='osgi.bundle' name='org.w3c.dom.smil' version='1.0.1.v200903091627'/>
        <provided namespace='java.package' name='org.w3c.dom.smil' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.events' range='[3.0.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.w3c.dom.smil' version='1.0.1.v200903091627'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.w3c.dom.smil&#xA;Bundle-Version: 1.0.1.v200903091627
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.w3c.dom.svg' version='1.1.0.v201011041433' singleton='false'>
      <update id='org.w3c.dom.svg' range='[0.0.0,1.1.0.v201011041433)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='W3C SVG DOM'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='2070'/>
        <property name='iplog.contact.name' value='Anthony Hunter'/>
        <property name='iplog.contact.email' value='anthonyh{at}ca.ibm.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.w3c.dom.svg' version='1.1.0.v201011041433'/>
        <provided namespace='osgi.bundle' name='org.w3c.dom.svg' version='1.1.0.v201011041433'/>
        <provided namespace='java.package' name='org.w3c.dom.svg' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.w3c.dom.smil' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.w3c.dom.svg' version='1.1.0.v201011041433'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.w3c.dom.svg&#xA;Bundle-Version: 1.1.0.v201011041433
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.yaml.snakeyaml' version='2.2.0' singleton='false' generation='2'>
      <update id='org.yaml.snakeyaml' range='[0.0.0,2.2.0)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='SnakeYAML'/>
        <property name='org.eclipse.equinox.p2.description' value='YAML 1.1 parser and emitter for Java'/>
      </properties>
      <provides size='25'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.yaml.snakeyaml' version='2.2.0'/>
        <provided namespace='osgi.bundle' name='org.yaml.snakeyaml' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.comments' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.composer' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.constructor' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.emitter' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.env' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.error' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.events' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.extensions.compactnotation' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.inspector' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.internal' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.introspector' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.nodes' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.parser' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.reader' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.representer' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.resolver' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.scanner' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.serializer' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.tokens' version='2.2.0'/>
        <provided namespace='java.package' name='org.yaml.snakeyaml.util' version='2.2.0'/>
        <provided namespace='osgi.identity' name='org.yaml.snakeyaml' version='2.2.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='java.package' name='org.yaml.snakeyaml' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.comments' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.composer' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.emitter' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.error' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.events' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.inspector' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.internal' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.introspector' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.nodes' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.parser' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.reader' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.resolver' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.scanner' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.serializer' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.yaml.snakeyaml.tokens' range='[2.2.0,3.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.yaml.snakeyaml
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.yaml.snakeyaml' version='2.2.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.yaml.snakeyaml&#xA;Bundle-Version: 2.2.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingCLI-E4.application' version='0.2.4'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.application' version='0.2.4'/>
      </provides>
      <requires size='13'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.1.1300.v20200819-0940,1.1.1300.v20200819-0940]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.cocoa.macosx.x86_64.Ultimate' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.gtk.linux.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.cocoa.macosx.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.5.800.v20200727-1323,1.5.800.v20200727-1323]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.executable.gtk.linux.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.win32.win32.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.win32.win32.x86_64.Ultimate' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.executable.win32.win32.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.gtk.linux.x86_64.Ultimate' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.1.1300.v20200819-0940,1.1.1300.v20200819-0940]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.1.1300.v20200819-0940,1.1.1300.v20200819-0940]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.executable.cocoa.macosx.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingCLI-E4.config.gtk.linux.x86_64' version='0.2.4' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.config.gtk.linux.x86_64' version='0.2.4'/>
        <provided namespace='toolingCLI-E4' name='CLI-E4.config' version='0.2.4'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.product,propValue:de.uni_freiburg.informatik.ultimate.core.CLI);setProgramProperty(propName:osgi.splashPath,propValue:platform${#58}/base/plugins/UltimateCore);setProgramProperty(propName:eclipse.application,propValue:de.uni_freiburg.informatik.ultimate.core.CoreRCP);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:osgi.splashPath,propValue:);setProgramProperty(propName:eclipse.application,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingCLI-E4.configuration' version='0.2.4'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.configuration' version='0.2.4'/>
      </provides>
      <requires size='21'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.osgi' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.ini.gtk.linux.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.common' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.config.win32.win32.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.config.cocoa.macosx.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.config.gtk.linux.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.ini.win32.win32.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.osgi' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.event' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.apache.felix.scr' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.osgi' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.ini.cocoa.macosx.x86_64' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.event' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.core.runtime' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.apache.felix.scr' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.core.runtime' range='[0.2.4,0.2.4]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingCLI-E4.executable.gtk.linux.x86_64' version='0.2.4' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.gtk.linux.x86_64' range='[0.2.4,0.2.4]'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.executable.gtk.linux.x86_64' version='0.2.4'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='CLI-E4.executable.gtk.linux.x86_64' range='[0.2.4,0.2.4]'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder}); chmod(targetDir:${installFolder}, targetFile:Ultimate, permissions:755);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingCLI-E4.ini.gtk.linux.x86_64' version='0.2.4' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingCLI-E4.ini.gtk.linux.x86_64' version='0.2.4'/>
        <provided namespace='toolingCLI-E4' name='CLI-E4.ini' version='0.2.4'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            addJvmArg(jvmArg:-Xmx8g);addJvmArg(jvmArg:-Xms4M);addProgramArg(programArg:--launcher.suppressErrors);addProgramArg(programArg:-nosplash);addProgramArg(programArg:-data);addProgramArg(programArg:@user.home/.ultimate);
          </instruction>
          <instruction key='unconfigure'>
            removeJvmArg(jvmArg:-Xmx8g);removeJvmArg(jvmArg:-Xms4M);removeProgramArg(programArg:--launcher.suppressErrors);removeProgramArg(programArg:-nosplash);removeProgramArg(programArg:-data);removeProgramArg(programArg:@user.home/.ultimate);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.apache.felix.scr' version='0.2.4' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.1.16.v20200110-1820'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.1.16.v20200110-1820'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='0.2.4' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.19.0.v20200724-1004'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.19.0.v20200724-1004'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='0.2.4' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.13.0.v20200828-1034'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.13.0.v20200828-1034'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='0.2.4' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='1.5.500.v20200616-0800'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='1.5.500.v20200616-0800'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.osgi' version='0.2.4' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.16.0.v20200828-0759'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.osgi' version='0.2.4'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.16.0.v20200828-0759'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.5.800.v20200727-1323' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.5.800.v20200727-1323'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.5.800.v20200727-1323'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.5.800.v20200727-1323'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='1.1.1300.v20200819-0940'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.1.1300.v20200819-0940'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='1.1.1300.v20200819-0940'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='202'>
    <iuProperties id='CLI-E4' version='0.2.4'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='CLI-E4.executable.gtk.linux.x86_64' version='0.2.4'>
      <properties size='1'>
        <property name='unzipped|@artifact|/storage/repos/ultimate-2/trunk/source/BA_SiteRepository/target/products/CLI-E4/linux/gtk/x86_64' value='/storage/repos/ultimate-2/trunk/source/BA_SiteRepository/target/products/CLI-E4/linux/gtk/x86_64/Ultimate|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
