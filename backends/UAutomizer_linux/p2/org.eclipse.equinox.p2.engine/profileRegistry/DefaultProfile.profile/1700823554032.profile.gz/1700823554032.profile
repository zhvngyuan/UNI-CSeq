<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1700823554032'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/storage/repos/ultimate-2/trunk/source/BA_SiteRepository/target/products/CLI-E4/linux/gtk/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_GB'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/storage/repos/ultimate-2/trunk/source/BA_SiteRepository/target/products/CLI-E4/linux/gtk/x86_64'/>
  </properties>
</profile>
